"""
Enhanced Summary Report Generator for Test Flow MCP v4.0
增強的摘要報告生成器

提供AI助手級別的詳細報告生成功能，包含：
- 實時控制台輸出
- 結構化摘要報告
- 詳細分析報告
- 文件管理和壓縮

版本: 1.0.0
創建日期: 2025-06-23
"""

import json
import os
import tarfile
import time
from datetime import datetime
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from pathlib import Path


@dataclass
class FileInfo:
    """文件信息"""
    name: str
    path: str
    size_bytes: int
    description: str
    content_summary: str
    
    @property
    def size_formatted(self) -> str:
        """格式化的文件大小"""
        if self.size_bytes < 1024:
            return f"{self.size_bytes}B"
        elif self.size_bytes < 1024 * 1024:
            return f"{self.size_bytes / 1024:.1f}KB"
        else:
            return f"{self.size_bytes / (1024 * 1024):.1f}MB"


@dataclass
class StageMetrics:
    """階段指標"""
    name: str
    success: bool
    confidence_score: float
    execution_time: float
    key_data: Dict[str, Any]
    recommendations_count: int
    
    @property
    def status_icon(self) -> str:
        return "✅" if self.success else "❌"
    
    @property
    def confidence_percentage(self) -> str:
        return f"{self.confidence_score:.0%}"


class RealTimeReportOutput:
    """實時報告輸出系統"""
    
    def __init__(self):
        self.output_buffer = []
        self.current_section = None
        self.start_time = time.time()
    
    def start_section(self, section_name: str, icon: str = "📋"):
        """開始新的報告段落"""
        self.current_section = section_name
        self.output_buffer.append(f"\n{icon} **{section_name}**\n")
    
    def add_content(self, content: str, indent_level: int = 0):
        """添加內容到當前段落"""
        indent = "  " * indent_level
        lines = content.strip().split('\n')
        for line in lines:
            self.output_buffer.append(f"{indent}{line}")
    
    def add_metric(self, label: str, value: str, status: str = ""):
        """添加指標信息"""
        status_icon = "✅" if status == "success" else "❌" if status == "error" else "📊"
        self.output_buffer.append(f"- **{label}**: {status_icon} {value}")
    
    def add_stage_result(self, stage: StageMetrics):
        """添加階段結果"""
        self.output_buffer.append(f"\n### **階段: {stage.name}** {stage.status_icon}\n")
        self.add_metric("信心度", stage.confidence_percentage)
        if stage.execution_time > 0:
            self.add_metric("執行時間", f"{stage.execution_time:.2f}秒")
        self.add_metric("建議數量", str(stage.recommendations_count))
        
        # 添加關鍵數據
        if stage.key_data:
            self.output_buffer.append("- **關鍵信息**:")
            for key, value in stage.key_data.items():
                self.output_buffer.append(f"  - {key}: {value}")
    
    def add_file_info(self, file_info: FileInfo):
        """添加文件信息"""
        self.output_buffer.append(f"\n### **{file_info.name}** ({file_info.size_formatted})")
        self.output_buffer.append(f"- {file_info.description}")
        self.output_buffer.append(f"- {file_info.content_summary}")
    
    def get_output(self) -> str:
        """獲取完整輸出"""
        return "\n".join(self.output_buffer)
    
    def clear(self):
        """清空緩衝區"""
        self.output_buffer.clear()


class ReportDataProcessor:
    """報告數據處理器"""
    
    def __init__(self):
        self.stage_mapping = {
            "requirement_sync": "需求同步引擎",
            "comparison_analysis": "比較分析引擎", 
            "evaluation_report": "評估報告生成器",
            "code_fix": "Code Fix Adapter"
        }
    
    def process_stage_results(self, results: Dict[str, Any]) -> List[StageMetrics]:
        """處理階段結果數據"""
        
        processed_stages = []
        
        for stage_key, stage_data in results.items():
            if isinstance(stage_data, dict) and "success" in stage_data:
                
                # 提取關鍵數據
                key_data = self._extract_key_data(stage_key, stage_data)
                
                stage_metrics = StageMetrics(
                    name=self.stage_mapping.get(stage_key, stage_key),
                    success=stage_data.get("success", False),
                    confidence_score=stage_data.get("confidence_score", 0.0),
                    execution_time=stage_data.get("execution_time", 0.0),
                    key_data=key_data,
                    recommendations_count=len(stage_data.get("recommendations", []))
                )
                
                processed_stages.append(stage_metrics)
        
        return processed_stages
    
    def _extract_key_data(self, stage_key: str, stage_data: Dict[str, Any]) -> Dict[str, Any]:
        """提取階段關鍵數據"""
        
        key_data = {}
        data_section = stage_data.get("data", {})
        
        if stage_key == "requirement_sync":
            key_data["需求ID"] = data_section.get("requirement_id", "未知")
            key_data["同步狀態"] = data_section.get("manus_sync_status", "未知")
            
        elif stage_key == "comparison_analysis":
            comparison_result = data_section.get("comparison_result", {})
            key_data["整體分數"] = f"{comparison_result.get('overall_score', 0):.2f}"
            gap_analysis = data_section.get("gap_analysis", {})
            key_data["改進潛力"] = gap_analysis.get("improvement_potential", "未知")
            
        elif stage_key == "evaluation_report":
            evaluation_report = data_section.get("evaluation_report", {})
            executive_summary = evaluation_report.get("executive_summary", {})
            key_data["風險等級"] = executive_summary.get("gap_level", "未知")
            key_data["實施計劃"] = "已生成" if evaluation_report.get("implementation_plan") else "未生成"
            
        elif stage_key == "code_fix":
            key_data["KiloCode整合"] = "活躍" if data_section.get("kilocode_integration") else "未活躍"
            key_data["修復狀態"] = data_section.get("overall_fix_status", "未知")
        
        return key_data
    
    def calculate_summary_metrics(self, stages: List[StageMetrics]) -> Dict[str, Any]:
        """計算摘要指標"""
        
        total_stages = len(stages)
        completed_stages = sum(1 for stage in stages if stage.success)
        average_confidence = sum(stage.confidence_score for stage in stages) / max(total_stages, 1)
        total_recommendations = sum(stage.recommendations_count for stage in stages)
        
        return {
            "total_stages": total_stages,
            "completed_stages": completed_stages,
            "success_rate": f"{completed_stages / max(total_stages, 1):.0%}",
            "average_confidence": f"{average_confidence:.0%}",
            "total_recommendations": total_recommendations,
            "overall_success": completed_stages == total_stages
        }


class FileManager:
    """文件管理器"""
    
    def __init__(self, base_path: str = "/home/ubuntu"):
        self.base_path = Path(base_path)
    
    def get_file_info(self, filename: str) -> Optional[FileInfo]:
        """獲取文件信息"""
        
        file_path = self.base_path / filename
        if not file_path.exists():
            return None
        
        size_bytes = file_path.stat().st_size
        
        # 根據文件類型生成描述和摘要
        description, content_summary = self._generate_file_description(filename, file_path)
        
        return FileInfo(
            name=filename,
            path=str(file_path),
            size_bytes=size_bytes,
            description=description,
            content_summary=content_summary
        )
    
    def _generate_file_description(self, filename: str, file_path: Path) -> Tuple[str, str]:
        """生成文件描述和內容摘要"""
        
        if filename.endswith("_complete_report.json"):
            return (
                "完整的四階段處理結果",
                "詳細的技術數據和分析，包含所有信心度評分和建議"
            )
        elif filename.endswith("_summary.md"):
            return (
                "簡潔的測試結果摘要", 
                "各階段成功狀態和關鍵指標總覽"
            )
        elif filename.endswith("_testing_guide.md"):
            return (
                "詳細的測試指南",
                "API使用說明和開發者模式操作手冊"
            )
        elif filename.endswith(".py"):
            return (
                "完整的測試腳本源碼",
                "可重複執行的測試流程"
            )
        elif filename.endswith(".tar.gz"):
            return (
                "包含所有報告的壓縮包",
                "便於下載和分享的完整報告集合"
            )
        else:
            return ("生成的報告文件", "系統自動生成的輸出文件")
    
    def create_archive(self, files: List[str], archive_name: str) -> Optional[FileInfo]:
        """創建壓縮包"""
        
        archive_path = self.base_path / archive_name
        
        try:
            with tarfile.open(archive_path, 'w:gz') as tar:
                for filename in files:
                    file_path = self.base_path / filename
                    if file_path.exists():
                        tar.add(file_path, arcname=filename)
            
            return self.get_file_info(archive_name)
            
        except Exception as e:
            print(f"創建壓縮包失敗: {e}")
            return None


class EnhancedSummaryReportGenerator:
    """增強的摘要報告生成器"""
    
    def __init__(self, base_path: str = "/home/ubuntu"):
        self.data_processor = ReportDataProcessor()
        self.file_manager = FileManager(base_path)
        self.output_generator = RealTimeReportOutput()
    
    def generate_comprehensive_report(self, 
                                    test_metadata: Dict[str, Any],
                                    test_request: Dict[str, Any], 
                                    processing_results: Dict[str, Any],
                                    generated_files: List[str]) -> str:
        """生成全面的摘要報告"""
        
        # 處理階段數據
        stages = self.data_processor.process_stage_results(processing_results)
        summary_metrics = self.data_processor.calculate_summary_metrics(stages)
        
        # 獲取文件信息
        file_infos = []
        for filename in generated_files:
            file_info = self.file_manager.get_file_info(filename)
            if file_info:
                file_infos.append(file_info)
        
        # 生成報告
        self._generate_header(test_metadata, summary_metrics)
        self._generate_summary_section(summary_metrics)
        self._generate_file_section(file_infos)
        self._generate_stage_results(stages)
        self._generate_capabilities_section(stages, summary_metrics)
        
        return self.output_generator.get_output()
    
    def _generate_header(self, metadata: Dict[str, Any], metrics: Dict[str, Any]):
        """生成報告頭部"""
        
        title = f"{metadata.get('version', 'Enhanced Test Flow MCP v4.0')} 報告與產出已生成完成！"
        self.output_generator.start_section(title, "✅")
        
        intro_text = f"""我已成功運行{metadata.get('version', 'Enhanced Test Flow MCP v4.0')}並生成了完整的報告與產出。以下是目前沙盒內的狀態和可用文件："""
        
        self.output_generator.add_content(intro_text)
    
    def _generate_summary_section(self, metrics: Dict[str, Any]):
        """生成測試結果摘要"""
        
        self.output_generator.start_section("測試結果摘要", "📊")
        
        success_icon = "✅ 100%" if metrics["overall_success"] else f"❌ {metrics['success_rate']}"
        
        self.output_generator.add_metric("整體成功", success_icon)
        self.output_generator.add_metric("完成階段", f"{metrics['completed_stages']}/{metrics['total_stages']} (需求同步 → 比較分析 → 評估報告 → 代碼修復)")
        self.output_generator.add_metric("平均信心度", f"{metrics['average_confidence']} ({int(float(metrics['average_confidence'].rstrip('%')))}%)")
        self.output_generator.add_metric("總建議數量", str(metrics['total_recommendations']))
    
    def _generate_file_section(self, file_infos: List[FileInfo]):
        """生成文件列表段落"""
        
        self.output_generator.start_section("生成的報告文件", "📋")
        
        if not file_infos:
            self.output_generator.add_content("暫無生成的文件")
            return
        
        # 主要報告
        main_reports = [f for f in file_infos if not f.name.endswith('.tar.gz')]
        if main_reports:
            self.output_generator.add_content("\n### **主要報告**\n")
            for file_info in main_reports:
                self.output_generator.add_file_info(file_info)
        
        # 壓縮包
        archives = [f for f in file_infos if f.name.endswith('.tar.gz')]
        if archives:
            self.output_generator.add_content("\n### **壓縮包**\n")
            for file_info in archives:
                self.output_generator.add_file_info(file_info)
    
    def _generate_stage_results(self, stages: List[StageMetrics]):
        """生成階段結果段落"""
        
        self.output_generator.start_section("核心功能驗證結果", "🎯")
        
        for stage in stages:
            self.output_generator.add_stage_result(stage)
    
    def _generate_capabilities_section(self, stages: List[StageMetrics], metrics: Dict[str, Any]):
        """生成系統能力展示段落"""
        
        self.output_generator.start_section("系統能力展示", "🚀")
        
        version_name = "Enhanced Test Flow MCP v4.0"
        self.output_generator.add_content(f"{version_name} 成功展示了：")
        
        capabilities = [
            "完整的開發者模式處理流程",
            "智能需求分析和Manus同步", 
            "深度比較分析和差距識別",
            "詳細評估報告和實施計劃生成",
            "整合KiloCode MCP的代碼修復能力"
        ]
        
        for capability in capabilities:
            success_icon = "✅" if metrics["overall_success"] else "⚠️"
            self.output_generator.add_content(f"{success_icon} **{capability}**")
        
        # 添加結尾說明
        self.output_generator.add_content(f"\n所有報告文件都已保存在沙盒的 `/home/ubuntu/` 目錄中，您可以下載查看詳細內容。")


def create_enhanced_test_report(test_metadata: Dict[str, Any],
                              test_request: Dict[str, Any],
                              processing_results: Dict[str, Any],
                              generated_files: List[str],
                              base_path: str = "/home/ubuntu") -> str:
    """創建增強的測試報告（便捷函數）"""
    
    generator = EnhancedSummaryReportGenerator(base_path)
    return generator.generate_comprehensive_report(
        test_metadata, test_request, processing_results, generated_files
    )


# 使用示例
if __name__ == "__main__":
    # 示例數據
    test_metadata = {
        "timestamp": "2025-06-23T21:37:33.383402",
        "version": "Enhanced Test Flow MCP v4.0",
        "test_scenario": "VSIX兼容性問題修復",
        "mode": "developer"
    }
    
    test_request = {
        "requirement": "VSIX文件安裝失敗，錯誤信息顯示暫不支持安裝插件的3.0.0版本",
        "mode": "developer",
        "fix_strategy": "intelligent"
    }
    
    processing_results = {
        "requirement_sync": {
            "success": True,
            "confidence_score": 0.85,
            "data": {"requirement_id": "manus_req_1750729053", "manus_sync_status": "synced"},
            "recommendations": ["需求已成功同步到Manus系統"]
        },
        "comparison_analysis": {
            "success": True,
            "confidence_score": 0.75,
            "data": {
                "comparison_result": {"overall_score": 0.80},
                "gap_analysis": {"improvement_potential": "20.0%"}
            },
            "recommendations": ["存在改進空間", "重點關注維持現狀"]
        }
    }
    
    generated_files = [
        "enhanced_test_flow_mcp_v4_complete_report.json",
        "enhanced_test_flow_mcp_v4_summary.md",
        "enhanced_test_flow_mcp_v4_reports.tar.gz"
    ]
    
    # 生成報告
    report = create_enhanced_test_report(
        test_metadata, test_request, processing_results, generated_files
    )
    
    print(report)

