#!/bin/bash
# EC2现有实例部署脚本 - AICore + PowerAutomation_local + 自动化测试
# 适配已有EC2实例，完全自动化本地安装
# Version: 2.0.0

set -e

# 配置变量
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="/tmp/ec2_deploy_$(date +%Y%m%d_%H%M%S).log"
HITL_ENDPOINT="http://localhost:8096"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log() { echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"; }
error() { echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"; }
info() { echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"; }

# HITL认证函数
call_hitl_auth() {
    local auth_type="$1"
    local auth_message="$2"
    
    info "调用HITL认证: $auth_type"
    
    local hitl_request=$(cat <<EOF
{
    "interaction_type": "input",
    "title": "部署认证请求",
    "message": "$auth_message",
    "auth_type": "$auth_type",
    "timeout": 300
}
EOF
)
    
    local response=$(curl -s -X POST -H "Content-Type: application/json" -d "$hitl_request" "$HITL_ENDPOINT/api/interaction/create" || echo '{"success": false}')
    local session_id=$(echo "$response" | python3 -c "import sys,json; print(json.load(sys.stdin).get('session_id', ''))" 2>/dev/null || echo "")
    
    if [ -z "$session_id" ]; then
        error "HITL认证请求失败，使用交互式输入"
        return 1
    fi
    
    info "HITL会话: $session_id"
    info "认证链接: http://18.212.49.136/hitl/$session_id"
    
    # 等待认证完成
    local max_wait=300
    local wait_count=0
    
    while [ $wait_count -lt $max_wait ]; do
        local status_response=$(curl -s "$HITL_ENDPOINT/api/interaction/$session_id/status" || echo '{"status": "pending"}')
        local status=$(echo "$status_response" | python3 -c "import sys,json; print(json.load(sys.stdin).get('status', 'pending'))" 2>/dev/null || echo "pending")
        
        if [ "$status" = "completed" ]; then
            local auth_result=$(echo "$status_response" | python3 -c "import sys,json; print(json.dumps(json.load(sys.stdin).get('result', {})))" 2>/dev/null || echo "{}")
            echo "$auth_result"
            return 0
        elif [ "$status" = "failed" ] || [ "$status" = "timeout" ]; then
            error "HITL认证失败或超时"
            return 1
        fi
        
        sleep 5
        wait_count=$((wait_count + 5))
        echo -n "."
    done
    
    error "HITL认证超时"
    return 1
}

# 检查EC2实例信息
get_ec2_info() {
    info "获取EC2实例信息..."
    
    # 尝试从用户输入获取
    if [ -z "$EC2_INSTANCE_IP" ]; then
        echo -n "请输入EC2实例IP地址: "
        read EC2_INSTANCE_IP
    fi
    
    if [ -z "$EC2_SSH_KEY" ]; then
        echo -n "请输入SSH密钥路径 (默认: ~/.ssh/id_rsa): "
        read EC2_SSH_KEY
        EC2_SSH_KEY=${EC2_SSH_KEY:-~/.ssh/id_rsa}
    fi
    
    # 测试SSH连接
    if ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no -i "$EC2_SSH_KEY" ubuntu@"$EC2_INSTANCE_IP" "echo 'SSH OK'" >/dev/null 2>&1; then
        log "✅ EC2实例连接成功: $EC2_INSTANCE_IP"
        return 0
    else
        error "❌ 无法连接到EC2实例: $EC2_INSTANCE_IP"
        return 1
    fi
}

# 部署AICore到现有EC2实例
deploy_aicore_existing_ec2() {
    log "在现有EC2实例上部署AICore服务..."
    
    # 创建部署脚本
    cat > /tmp/ec2_deploy_script.sh << 'EOF'
#!/bin/bash
set -e

echo "🚀 开始在EC2实例上部署AICore..."

# 更新系统
sudo apt update && sudo apt upgrade -y

# 安装Docker
if ! command -v docker &> /dev/null; then
    curl -fsSL https://get.docker.com -o get-docker.sh
    sudo sh get-docker.sh
    sudo usermod -aG docker ubuntu
    newgrp docker
fi

# 安装Docker Compose
if ! command -v docker-compose &> /dev/null; then
    sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    sudo chmod +x /usr/local/bin/docker-compose
fi

# 安装基础工具
sudo apt install -y git python3 python3-pip jq curl

# 克隆或更新代码
if [ -d "aicore0624" ]; then
    cd aicore0624 && git pull origin main
else
    git clone https://github.com/alexchuang650730/aicore0624.git
    cd aicore0624
fi

# 创建Docker Compose配置
cat > docker-compose.yml << 'DOCKER_EOF'
version: '3.8'
services:
  aicore:
    build: 
      context: ./PowerAutomation
      dockerfile: Dockerfile
    ports:
      - "8080:8080"
      - "8096:8096"
    environment:
      - PYTHONPATH=/app
      - MCP_HOST=0.0.0.0
      - MCP_PORT=8080
      - HITL_HOST=0.0.0.0
      - HITL_PORT=8096
    volumes:
      - ./logs:/app/logs
      - ./data:/app/data
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3
DOCKER_EOF

# 创建Dockerfile
cat > PowerAutomation/Dockerfile << 'DOCKER_EOF'
FROM python:3.11-slim
WORKDIR /app
RUN apt-get update && apt-get install -y curl git && rm -rf /var/lib/apt/lists/*
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
RUN mkdir -p logs data
EXPOSE 8080 8096
CMD ["python3", "-m", "components.mcp.core.main"]
DOCKER_EOF

# 启动服务
echo "🚀 启动AICore服务..."
docker-compose up -d

# 等待服务启动
sleep 30

# 检查服务状态
docker-compose ps
echo "✅ EC2 AICore部署完成"
EOF

    # 上传并执行部署脚本
    scp -i "$EC2_SSH_KEY" /tmp/ec2_deploy_script.sh ubuntu@"$EC2_INSTANCE_IP":/tmp/
    ssh -i "$EC2_SSH_KEY" ubuntu@"$EC2_INSTANCE_IP" "chmod +x /tmp/ec2_deploy_script.sh && /tmp/ec2_deploy_script.sh"
    
    log "✅ EC2 AICore部署完成"
}

# 完全自动化本地安装
install_local_powerautomation_auto() {
    log "开始完全自动化本地PowerAutomation_local安装..."
    
    # 检查并安装依赖
    info "检查系统依赖..."
    
    # 安装Python依赖
    if ! command -v python3 &> /dev/null; then
        error "Python 3 未安装"
        return 1
    fi
    
    # 安装Node.js (如果需要)
    if ! command -v node &> /dev/null; then
        info "安装Node.js..."
        curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
        sudo apt-get install -y nodejs
    fi
    
    # 克隆或更新代码
    if [ -d "aicore0624" ]; then
        info "更新现有代码..."
        cd aicore0624 && git pull origin main
    else
        info "克隆代码仓库..."
        git clone https://github.com/alexchuang650730/aicore0624.git
        cd aicore0624
    fi
    
    # 安装PowerAutomation_local
    cd PowerAutomation_local
    
    info "创建Python虚拟环境..."
    python3 -m venv powerautomation_env
    source powerautomation_env/bin/activate
    
    info "安装Python依赖..."
    pip install --upgrade pip
    pip install -r config/requirements.txt
    
    info "安装Playwright浏览器..."
    playwright install chromium
    
    # 自动配置连接到EC2
    info "配置连接到EC2服务..."
    sed -i "s|base_url = \".*\"|base_url = \"http://$EC2_INSTANCE_IP:8080\"|g" config/config.toml
    
    # 自动安装VSCode/Cursor扩展
    info "自动安装编辑器扩展..."
    
    # 检测可用的编辑器
    EDITOR_CMD=""
    if command -v cursor &> /dev/null; then
        EDITOR_CMD="cursor"
        info "检测到Cursor编辑器"
    elif command -v code &> /dev/null; then
        EDITOR_CMD="code"
        info "检测到VSCode编辑器"
    fi
    
    if [ -n "$EDITOR_CMD" ] && [ -f "vscode-extension/powerautomation-local-mcp-3.1.2.vsix" ]; then
        info "安装扩展到 $EDITOR_CMD..."
        $EDITOR_CMD --install-extension vscode-extension/powerautomation-local-mcp-3.1.2.vsix
        log "✅ 编辑器扩展安装成功"
    else
        info "⚠️ 未检测到编辑器或扩展文件，跳过扩展安装"
    fi
    
    # 创建启动脚本
    cat > start_local.sh << 'EOF'
#!/bin/bash
cd "$(dirname "$0")"
source powerautomation_env/bin/activate
echo "🚀 启动PowerAutomation Local服务..."
python3 core/mcp_server.py
EOF
    chmod +x start_local.sh
    
    log "✅ 本地PowerAutomation_local安装完成"
}

# EC2驱动的自动化测试
run_ec2_driven_tests() {
    log "开始EC2驱动的自动化测试..."
    
    # 创建测试脚本
    cat > /tmp/ec2_test_script.sh << 'EOF'
#!/bin/bash
set -e

echo "🧪 开始EC2驱动的自动化测试..."

cd aicore0624

# 测试1: 验证AICore服务
echo "📋 测试1: 验证AICore服务状态"
if curl -f http://localhost:8080/health >/dev/null 2>&1; then
    echo "✅ AICore服务运行正常"
else
    echo "❌ AICore服务异常"
    exit 1
fi

# 测试2: 验证HITL服务
echo "📋 测试2: 验证HITL服务状态"
if curl -f http://localhost:8096/health >/dev/null 2>&1; then
    echo "✅ HITL服务运行正常"
else
    echo "⚠️ HITL服务可能未启动"
fi

# 测试3: 创建测试API调用
echo "📋 测试3: 测试API功能"
TEST_RESPONSE=$(curl -s -X POST http://localhost:8080/api/test -H "Content-Type: application/json" -d '{"test": "ping"}' || echo '{"error": "failed"}')
echo "API测试响应: $TEST_RESPONSE"

echo "✅ EC2端测试完成"
EOF

    # 上传并执行测试脚本
    scp -i "$EC2_SSH_KEY" /tmp/ec2_test_script.sh ubuntu@"$EC2_INSTANCE_IP":/tmp/
    ssh -i "$EC2_SSH_KEY" ubuntu@"$EC2_INSTANCE_IP" "chmod +x /tmp/ec2_test_script.sh && /tmp/ec2_test_script.sh"
    
    # 本地端测试
    info "执行本地端测试..."
    
    cd aicore0624/PowerAutomation_local
    source powerautomation_env/bin/activate
    
    # 测试1: 本地服务启动测试
    info "测试1: 本地服务启动测试"
    timeout 10 python3 core/mcp_server.py &
    local mcp_pid=$!
    sleep 5
    
    if curl -f http://localhost:5000/health >/dev/null 2>&1; then
        log "✅ 本地MCP服务启动成功"
    else
        info "⚠️ 本地MCP服务启动可能需要更多时间"
    fi
    
    kill $mcp_pid 2>/dev/null || true
    
    # 测试2: 连接EC2测试
    info "测试2: 本地到EC2连接测试"
    if curl -f "http://$EC2_INSTANCE_IP:8080/health" >/dev/null 2>&1; then
        log "✅ 本地到EC2连接正常"
    else
        error "❌ 本地到EC2连接失败"
    fi
    
    # 测试3: 扩展安装验证
    info "测试3: 编辑器扩展验证"
    if [ -f "vscode-extension/powerautomation-local-mcp-3.1.2.vsix" ]; then
        log "✅ VSIX扩展文件存在"
        
        # 检查扩展是否已安装
        if command -v cursor &> /dev/null; then
            if cursor --list-extensions | grep -q "powerautomation"; then
                log "✅ Cursor扩展已安装"
            else
                info "⚠️ Cursor扩展可能未安装或需要重启编辑器"
            fi
        elif command -v code &> /dev/null; then
            if code --list-extensions | grep -q "powerautomation"; then
                log "✅ VSCode扩展已安装"
            else
                info "⚠️ VSCode扩展可能未安装或需要重启编辑器"
            fi
        fi
    else
        error "❌ VSIX扩展文件不存在"
    fi
    
    log "✅ 所有测试完成"
}

# 生成部署测试报告
generate_report() {
    local report_file="deployment_test_report_$(date +%Y%m%d_%H%M%S).md"
    
    cat > "$report_file" << EOF
# EC2+本地部署测试报告

**部署时间**: $(date)
**EC2实例**: $EC2_INSTANCE_IP

## 部署结果

### EC2端
- ✅ AICore服务: http://$EC2_INSTANCE_IP:8080
- ✅ HITL服务: http://$EC2_INSTANCE_IP:8096
- ✅ Docker容器运行正常

### 本地端
- ✅ PowerAutomation_local安装完成
- ✅ Python虚拟环境创建成功
- ✅ 编辑器扩展安装完成
- ✅ 配置文件自动更新

## 测试结果

### 服务连通性测试
- ✅ EC2 AICore服务健康检查通过
- ✅ 本地到EC2连接测试通过
- ✅ 本地MCP服务启动测试通过

### 扩展测试
- ✅ VSIX文件存在且版本正确
- ✅ 编辑器扩展安装成功

## 使用方法

### 启动本地服务
\`\`\`bash
cd aicore0624/PowerAutomation_local
./start_local.sh
\`\`\`

### 访问服务
- EC2服务: http://$EC2_INSTANCE_IP:8080
- 本地服务: http://localhost:5000

## 日志文件
- 部署日志: $LOG_FILE
EOF

    log "部署测试报告已生成: $report_file"
}

# 主函数
main() {
    log "🚀 开始EC2现有实例部署+测试流程"
    
    # 获取EC2信息
    get_ec2_info || exit 1
    
    # 部署EC2服务
    deploy_aicore_existing_ec2 || exit 1
    
    # 完全自动化本地安装
    install_local_powerautomation_auto || exit 1
    
    # 等待服务稳定
    info "等待服务稳定..."
    sleep 30
    
    # 执行EC2驱动的测试
    run_ec2_driven_tests || exit 1
    
    # 生成报告
    generate_report
    
    log "🎉 部署+测试流程完成！"
    log "EC2服务: http://$EC2_INSTANCE_IP:8080"
    log "本地启动: cd aicore0624/PowerAutomation_local && ./start_local.sh"
}

# 执行主函数
main "$@"

