#!/bin/bash
# EC2 一键部署脚本 - AICore核心服务 + PowerAutomation_local
# 支持HITL认证机制
# Version: 1.0.0
# Date: 2025-06-28

set -e  # 遇到错误立即退出

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 配置变量
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="/tmp/ec2_deploy_$(date +%Y%m%d_%H%M%S).log"
HITL_ENDPOINT="http://localhost:8096"
SMARTUI_ENDPOINT="http://18.212.49.136"
EC2_INSTANCE_TYPE="t3.medium"
EC2_REGION="us-east-1"

# 认证状态
AUTH_STATUS="pending"
AUTH_TOKEN=""
AWS_CREDENTIALS_SET=false
GITHUB_TOKEN=""

# 日志函数
log() {
    echo -e "${GREEN}[$(date '+%Y-%m-%d %H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOG_FILE"
}

info() {
    echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"
}

# HITL认证函数
call_hitl_auth() {
    local auth_type="$1"
    local auth_message="$2"
    local auth_data="$3"
    
    info "调用HITL认证: $auth_type"
    
    # 构建HITL请求
    local hitl_request=$(cat <<EOF
{
    "interaction_type": "input",
    "title": "部署认证请求",
    "message": "$auth_message",
    "auth_type": "$auth_type",
    "required_fields": $auth_data,
    "timeout": 300,
    "callback_url": "http://localhost:8080/auth/callback"
}
EOF
)
    
    # 发送HITL请求
    local response=$(curl -s -X POST \
        -H "Content-Type: application/json" \
        -d "$hitl_request" \
        "$HITL_ENDPOINT/api/interaction/create" || echo '{"success": false}')
    
    local session_id=$(echo "$response" | jq -r '.session_id // empty')
    
    if [ -z "$session_id" ]; then
        error "HITL认证请求失败"
        return 1
    fi
    
    info "HITL会话创建成功: $session_id"
    info "请在SmartUI界面完成认证: $SMARTUI_ENDPOINT/hitl/$session_id"
    
    # 等待用户完成认证
    local max_wait=300  # 5分钟超时
    local wait_count=0
    
    while [ $wait_count -lt $max_wait ]; do
        local status_response=$(curl -s "$HITL_ENDPOINT/api/interaction/$session_id/status" || echo '{"status": "pending"}')
        local status=$(echo "$status_response" | jq -r '.status // "pending"')
        
        if [ "$status" = "completed" ]; then
            local auth_result=$(echo "$status_response" | jq -r '.result // "{}"')
            echo "$auth_result"
            return 0
        elif [ "$status" = "failed" ] || [ "$status" = "timeout" ]; then
            error "HITL认证失败或超时"
            return 1
        fi
        
        sleep 5
        wait_count=$((wait_count + 5))
        echo -n "."
    done
    
    error "HITL认证超时"
    return 1
}

# 检查AWS认证
check_aws_auth() {
    info "检查AWS认证状态..."
    
    if aws sts get-caller-identity >/dev/null 2>&1; then
        log "AWS认证已配置"
        AWS_CREDENTIALS_SET=true
        return 0
    fi
    
    warning "AWS认证未配置，调用HITL获取认证信息"
    
    local auth_fields='[
        {"name": "aws_access_key_id", "type": "text", "required": true, "label": "AWS Access Key ID"},
        {"name": "aws_secret_access_key", "type": "password", "required": true, "label": "AWS Secret Access Key"},
        {"name": "aws_region", "type": "text", "required": false, "label": "AWS Region", "default": "us-east-1"}
    ]'
    
    local auth_result=$(call_hitl_auth "aws_credentials" "请提供AWS认证信息以继续部署" "$auth_fields")
    
    if [ $? -eq 0 ]; then
        # 解析认证结果并设置环境变量
        export AWS_ACCESS_KEY_ID=$(echo "$auth_result" | jq -r '.aws_access_key_id')
        export AWS_SECRET_ACCESS_KEY=$(echo "$auth_result" | jq -r '.aws_secret_access_key')
        export AWS_DEFAULT_REGION=$(echo "$auth_result" | jq -r '.aws_region // "us-east-1"')
        
        log "AWS认证信息已通过HITL获取并设置"
        AWS_CREDENTIALS_SET=true
        return 0
    else
        error "无法获取AWS认证信息"
        return 1
    fi
}

# 检查GitHub认证
check_github_auth() {
    info "检查GitHub认证状态..."
    
    if [ -n "$GITHUB_TOKEN" ] || [ -n "$GITHUB_PAT" ]; then
        log "GitHub认证已配置"
        return 0
    fi
    
    warning "GitHub认证未配置，调用HITL获取认证信息"
    
    local auth_fields='[
        {"name": "github_token", "type": "password", "required": true, "label": "GitHub Personal Access Token"},
        {"name": "github_username", "type": "text", "required": false, "label": "GitHub Username"}
    ]'
    
    local auth_result=$(call_hitl_auth "github_credentials" "请提供GitHub认证信息以访问代码仓库" "$auth_fields")
    
    if [ $? -eq 0 ]; then
        export GITHUB_TOKEN=$(echo "$auth_result" | jq -r '.github_token')
        export GITHUB_USERNAME=$(echo "$auth_result" | jq -r '.github_username // ""')
        
        log "GitHub认证信息已通过HITL获取并设置"
        return 0
    else
        error "无法获取GitHub认证信息"
        return 1
    fi
}

# 部署AICore到EC2
deploy_aicore_to_ec2() {
    log "开始部署AICore核心服务到EC2..."
    
    # 检查是否已有运行的实例
    local existing_instance=$(aws ec2 describe-instances \
        --filters "Name=tag:Name,Values=AICore-PowerAutomation" \
                  "Name=instance-state-name,Values=running" \
        --query 'Reservations[0].Instances[0].InstanceId' \
        --output text 2>/dev/null || echo "None")
    
    if [ "$existing_instance" != "None" ] && [ "$existing_instance" != "null" ]; then
        warning "发现已运行的AICore实例: $existing_instance"
        info "使用现有实例继续部署"
        EC2_INSTANCE_ID="$existing_instance"
    else
        info "创建新的EC2实例..."
        
        # 创建EC2实例
        local instance_result=$(aws ec2 run-instances \
            --image-id ami-0c02fb55956c7d316 \
            --instance-type "$EC2_INSTANCE_TYPE" \
            --key-name "powerautomation-key" \
            --security-group-ids "sg-0123456789abcdef0" \
            --subnet-id "subnet-0123456789abcdef0" \
            --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=AICore-PowerAutomation},{Key=Project,Value=PowerAutomation}]" \
            --user-data file://ec2_userdata.sh \
            --output json)
        
        EC2_INSTANCE_ID=$(echo "$instance_result" | jq -r '.Instances[0].InstanceId')
        
        if [ -z "$EC2_INSTANCE_ID" ] || [ "$EC2_INSTANCE_ID" = "null" ]; then
            error "EC2实例创建失败"
            return 1
        fi
        
        log "EC2实例创建成功: $EC2_INSTANCE_ID"
        
        # 等待实例启动
        info "等待EC2实例启动..."
        aws ec2 wait instance-running --instance-ids "$EC2_INSTANCE_ID"
    fi
    
    # 获取实例公网IP
    EC2_PUBLIC_IP=$(aws ec2 describe-instances \
        --instance-ids "$EC2_INSTANCE_ID" \
        --query 'Reservations[0].Instances[0].PublicIpAddress' \
        --output text)
    
    log "EC2实例公网IP: $EC2_PUBLIC_IP"
    
    # 等待SSH可用
    info "等待SSH服务可用..."
    local ssh_ready=false
    local max_attempts=30
    local attempt=0
    
    while [ $attempt -lt $max_attempts ] && [ "$ssh_ready" = false ]; do
        if ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no ubuntu@"$EC2_PUBLIC_IP" "echo 'SSH Ready'" >/dev/null 2>&1; then
            ssh_ready=true
            log "SSH连接已就绪"
        else
            sleep 10
            attempt=$((attempt + 1))
            echo -n "."
        fi
    done
    
    if [ "$ssh_ready" = false ]; then
        error "SSH连接超时"
        return 1
    fi
    
    # 部署AICore服务
    info "在EC2实例上部署AICore服务..."
    
    ssh ubuntu@"$EC2_PUBLIC_IP" << 'EOF'
        # 更新系统
        sudo apt update && sudo apt upgrade -y
        
        # 安装Docker
        curl -fsSL https://get.docker.com -o get-docker.sh
        sudo sh get-docker.sh
        sudo usermod -aG docker ubuntu
        
        # 安装Docker Compose
        sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        sudo chmod +x /usr/local/bin/docker-compose
        
        # 克隆AICore代码
        git clone https://github.com/alexchuang650730/aicore0624.git
        cd aicore0624
        
        # 启动AICore服务
        docker-compose up -d
        
        # 等待服务启动
        sleep 30
        
        # 检查服务状态
        docker-compose ps
EOF
    
    log "AICore核心服务部署完成"
    return 0
}

# 安装本地PowerAutomation_local
install_local_powerautomation() {
    log "开始安装本地PowerAutomation_local组件..."
    
    # 检查本地环境
    info "检查本地环境..."
    
    # 检查Python
    if ! command -v python3 &> /dev/null; then
        error "Python 3 未安装，请先安装Python 3.8+"
        return 1
    fi
    
    # 检查Node.js (用于VSCode扩展)
    if ! command -v node &> /dev/null; then
        warning "Node.js 未安装，将跳过VSCode扩展编译"
    fi
    
    # 克隆或更新代码
    if [ -d "aicore0624" ]; then
        info "更新现有代码..."
        cd aicore0624
        git pull origin main
    else
        info "克隆代码仓库..."
        git clone https://github.com/alexchuang650730/aicore0624.git
        cd aicore0624
    fi
    
    # 安装PowerAutomation_local
    cd PowerAutomation_local
    
    info "创建Python虚拟环境..."
    python3 -m venv powerautomation_env
    source powerautomation_env/bin/activate
    
    info "安装Python依赖..."
    pip install --upgrade pip
    pip install -r config/requirements.txt
    
    info "安装Playwright浏览器..."
    playwright install chromium
    
    # 配置连接到EC2服务
    info "配置连接到EC2 AICore服务..."
    
    # 更新配置文件
    sed -i "s|base_url = \".*\"|base_url = \"http://$EC2_PUBLIC_IP:8080\"|g" config/config.toml
    
    # 安装VSCode扩展
    if command -v code &> /dev/null; then
        info "安装VSCode扩展..."
        cd vscode-extension
        
        if [ -f "powerautomation-local-mcp-3.1.2.vsix" ]; then
            code --install-extension powerautomation-local-mcp-3.1.2.vsix
            log "VSCode扩展安装成功"
        else
            warning "VSCode扩展文件不存在，跳过安装"
        fi
        
        cd ..
    else
        warning "VSCode 未安装，跳过扩展安装"
    fi
    
    # 运行基本测试
    info "运行基本测试..."
    python3 -c "
import sys
sys.path.append('.')
from core.mcp_server import MCPServer
print('PowerAutomation_local 安装验证成功')
"
    
    log "PowerAutomation_local 安装完成"
    return 0
}

# 验证部署
verify_deployment() {
    log "验证部署状态..."
    
    # 验证EC2服务
    info "验证EC2 AICore服务..."
    local health_check=$(curl -s "http://$EC2_PUBLIC_IP:8080/health" || echo '{"status": "error"}')
    local ec2_status=$(echo "$health_check" | jq -r '.status // "error"')
    
    if [ "$ec2_status" = "ok" ] || [ "$ec2_status" = "healthy" ]; then
        log "✅ EC2 AICore服务运行正常"
    else
        error "❌ EC2 AICore服务异常"
        return 1
    fi
    
    # 验证本地服务
    info "验证本地PowerAutomation_local服务..."
    cd aicore0624/PowerAutomation_local
    source powerautomation_env/bin/activate
    
    # 启动本地MCP服务器进行测试
    timeout 10 python3 core/mcp_server.py &
    local mcp_pid=$!
    sleep 5
    
    local local_health=$(curl -s "http://localhost:5000/health" || echo '{"status": "error"}')
    local local_status=$(echo "$local_health" | jq -r '.status // "error"')
    
    kill $mcp_pid 2>/dev/null || true
    
    if [ "$local_status" = "ok" ] || [ "$local_status" = "healthy" ]; then
        log "✅ 本地PowerAutomation_local服务正常"
    else
        warning "⚠️ 本地PowerAutomation_local服务可能需要手动启动"
    fi
    
    # 验证连接
    info "验证本地到EC2的连接..."
    local connection_test=$(curl -s "http://$EC2_PUBLIC_IP:8080/api/ping" || echo '{"success": false}')
    local connection_ok=$(echo "$connection_test" | jq -r '.success // false')
    
    if [ "$connection_ok" = "true" ]; then
        log "✅ 本地到EC2连接正常"
    else
        warning "⚠️ 本地到EC2连接可能存在问题，请检查网络和防火墙设置"
    fi
    
    return 0
}

# 生成部署报告
generate_deployment_report() {
    local report_file="deployment_report_$(date +%Y%m%d_%H%M%S).md"
    
    cat > "$report_file" << EOF
# EC2 一键部署报告

**部署时间**: $(date)
**部署版本**: 1.0.0

## 部署结果

### EC2 AICore服务
- **实例ID**: $EC2_INSTANCE_ID
- **公网IP**: $EC2_PUBLIC_IP
- **服务端点**: http://$EC2_PUBLIC_IP:8080
- **状态**: ✅ 运行正常

### 本地PowerAutomation_local
- **安装路径**: $(pwd)/aicore0624/PowerAutomation_local
- **虚拟环境**: powerautomation_env
- **配置文件**: config/config.toml
- **状态**: ✅ 安装完成

## 使用方法

### 启动本地服务
\`\`\`bash
cd aicore0624/PowerAutomation_local
source powerautomation_env/bin/activate
python3 core/mcp_server.py
\`\`\`

### VSCode扩展
- 扩展已安装到VSCode
- 默认连接到: http://$EC2_PUBLIC_IP:8080

## 认证信息
- AWS认证: $([ "$AWS_CREDENTIALS_SET" = true ] && echo "✅ 已配置" || echo "❌ 未配置")
- GitHub认证: $([ -n "$GITHUB_TOKEN" ] && echo "✅ 已配置" || echo "❌ 未配置")

## 日志文件
- 部署日志: $LOG_FILE

EOF

    log "部署报告已生成: $report_file"
}

# 主函数
main() {
    log "🚀 开始EC2一键部署 - AICore + PowerAutomation_local"
    log "日志文件: $LOG_FILE"
    
    # 检查依赖
    info "检查系统依赖..."
    for cmd in curl jq aws git; do
        if ! command -v $cmd &> /dev/null; then
            error "缺少依赖: $cmd"
            exit 1
        fi
    done
    
    # 检查认证
    check_aws_auth || exit 1
    check_github_auth || exit 1
    
    # 部署EC2服务
    deploy_aicore_to_ec2 || exit 1
    
    # 安装本地组件
    install_local_powerautomation || exit 1
    
    # 验证部署
    verify_deployment || exit 1
    
    # 生成报告
    generate_deployment_report
    
    log "🎉 EC2一键部署完成！"
    log "EC2服务地址: http://$EC2_PUBLIC_IP:8080"
    log "本地服务启动: cd aicore0624/PowerAutomation_local && source powerautomation_env/bin/activate && python3 core/mcp_server.py"
}

# 信号处理
trap 'error "部署被中断"; exit 1' INT TERM

# 执行主函数
main "$@"

