#!/bin/bash
# EC2 UserData Script - AICore自动部署
# 在EC2实例启动时自动执行

# 设置日志
exec > >(tee /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1

echo "开始EC2 AICore自动部署..."

# 更新系统
apt-get update
apt-get upgrade -y

# 安装基础工具
apt-get install -y curl wget git jq unzip

# 安装Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh
usermod -aG docker ubuntu

# 安装Docker Compose
curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

# 安装Python和Node.js
apt-get install -y python3 python3-pip python3-venv nodejs npm

# 创建工作目录
mkdir -p /opt/powerautomation
cd /opt/powerautomation

# 克隆代码仓库
git clone https://github.com/alexchuang650730/aicore0624.git
cd aicore0624

# 创建Docker Compose配置
cat > docker-compose.yml << 'EOF'
version: '3.8'

services:
  aicore:
    build: 
      context: ./PowerAutomation
      dockerfile: Dockerfile
    ports:
      - "8080:8080"
      - "8096:8096"  # HITL服务端口
    environment:
      - PYTHONPATH=/app
      - MCP_HOST=0.0.0.0
      - MCP_PORT=8080
      - HITL_HOST=0.0.0.0
      - HITL_PORT=8096
    volumes:
      - ./logs:/app/logs
      - ./data:/app/data
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8080/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    restart: unless-stopped

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
    depends_on:
      - aicore
    restart: unless-stopped
EOF

# 创建Dockerfile
cat > PowerAutomation/Dockerfile << 'EOF'
FROM python:3.11-slim

WORKDIR /app

# 安装系统依赖
RUN apt-get update && apt-get install -y \
    curl \
    git \
    && rm -rf /var/lib/apt/lists/*

# 复制requirements文件
COPY requirements.txt .

# 安装Python依赖
RUN pip install --no-cache-dir -r requirements.txt

# 复制应用代码
COPY . .

# 创建日志和数据目录
RUN mkdir -p logs data

# 暴露端口
EXPOSE 8080 8096

# 启动脚本
CMD ["python3", "-m", "components.mcp.core.main"]
EOF

# 创建Nginx配置
cat > nginx.conf << 'EOF'
events {
    worker_connections 1024;
}

http {
    upstream aicore {
        server aicore:8080;
    }
    
    upstream hitl {
        server aicore:8096;
    }

    server {
        listen 80;
        server_name _;

        location / {
            proxy_pass http://aicore;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        location /hitl/ {
            proxy_pass http://hitl/;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            proxy_set_header Upgrade $http_upgrade;
            proxy_set_header Connection "upgrade";
        }

        location /health {
            proxy_pass http://aicore/health;
        }
    }
}
EOF

# 启动服务
echo "启动AICore服务..."
docker-compose up -d

# 等待服务启动
sleep 60

# 检查服务状态
docker-compose ps
docker-compose logs --tail=50

# 创建健康检查脚本
cat > /opt/powerautomation/health_check.sh << 'EOF'
#!/bin/bash
# 健康检查脚本

cd /opt/powerautomation/aicore0624

# 检查Docker服务
if ! docker-compose ps | grep -q "Up"; then
    echo "重启Docker服务..."
    docker-compose restart
fi

# 检查AICore健康状态
if ! curl -f http://localhost:8080/health >/dev/null 2>&1; then
    echo "AICore服务异常，重启中..."
    docker-compose restart aicore
fi
EOF

chmod +x /opt/powerautomation/health_check.sh

# 设置定时健康检查
echo "*/5 * * * * /opt/powerautomation/health_check.sh" | crontab -

# 设置开机自启
cat > /etc/systemd/system/powerautomation.service << 'EOF'
[Unit]
Description=PowerAutomation AICore Service
Requires=docker.service
After=docker.service

[Service]
Type=oneshot
RemainAfterExit=yes
WorkingDirectory=/opt/powerautomation/aicore0624
ExecStart=/usr/local/bin/docker-compose up -d
ExecStop=/usr/local/bin/docker-compose down
TimeoutStartSec=0

[Install]
WantedBy=multi-user.target
EOF

systemctl enable powerautomation.service

echo "EC2 AICore部署完成！"
echo "服务端点: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4):8080"
echo "HITL端点: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4):8096"

