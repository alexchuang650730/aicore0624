#!/bin/bash
# PowerAutomation Local 增强版一键部署脚本
# 功能: 检测、安装、配置、启动、测试 - 真正的一键部署
# Version: 3.0.0

set -e

# 配置变量
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="/tmp/start_local_$(date +%Y%m%d_%H%M%S).log"
PROJECT_DIR="aicore0624/PowerAutomation_local"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log() { echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"; }
error() { echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"; }
info() { echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"; }
success() { echo -e "${GREEN}[SUCCESS]${NC} $1" | tee -a "$LOG_FILE"; }
warning() { echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOG_FILE"; }

# 进度显示
show_progress() {
    local step=$1
    local total=$2
    local desc="$3"
    local percent=$((step * 100 / total))
    printf "\r${BLUE}[%2d/%d]${NC} (%3d%%) %s" $step $total $percent "$desc"
}

# 检查并创建项目目录
ensure_project_directory() {
    log "🔍 检查项目目录..."
    
    if [ ! -d "$PROJECT_DIR" ]; then
        info "项目目录不存在，开始克隆..."
        
        # 智能克隆
        if command -v git >/dev/null 2>&1; then
            git clone --depth 1 https://github.com/alexchuang650730/aicore0624.git >/dev/null 2>&1
            success "✅ 项目克隆完成"
        else
            error "❌ Git未安装，请先安装Git"
            exit 1
        fi
    else
        info "项目目录已存在，更新代码..."
        cd "$PROJECT_DIR" && git pull origin main >/dev/null 2>&1 || true
    fi
    
    cd "$PROJECT_DIR"
}

# 智能环境检测和安装
smart_environment_setup() {
    log "⚙️ 智能环境检测和安装..."
    
    show_progress 1 8 "检查Python环境"
    
    # 检查Python
    if ! command -v python3 >/dev/null 2>&1; then
        error "❌ Python 3未安装，请先安装Python 3.8+"
        exit 1
    fi
    
    local python_version=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1-2)
    info "Python版本: $python_version"
    
    show_progress 2 8 "检查虚拟环境"
    
    # 创建或激活虚拟环境
    if [ ! -d "powerautomation_env" ]; then
        info "创建虚拟环境..."
        python3 -m venv powerautomation_env >/dev/null 2>&1
    fi
    
    source powerautomation_env/bin/activate
    success "✅ 虚拟环境已激活"
    
    show_progress 3 8 "升级pip"
    pip install --upgrade pip >/dev/null 2>&1
    
    show_progress 4 8 "检查依赖文件"
    
    # 创建requirements.txt如果不存在
    if [ ! -f "requirements.txt" ]; then
        cat > requirements.txt << EOF
fastapi>=0.104.0
uvicorn[standard]>=0.24.0
pydantic>=2.5.0
aiohttp>=3.9.0
asyncio-mqtt>=0.13.0
playwright>=1.40.0
websockets>=12.0
python-multipart>=0.0.6
jinja2>=3.1.0
EOF
    fi
    
    show_progress 5 8 "安装Python依赖"
    pip install -r requirements.txt >/dev/null 2>&1
    
    show_progress 6 8 "安装Playwright浏览器"
    if command -v playwright >/dev/null 2>&1; then
        playwright install chromium >/dev/null 2>&1 || true
    fi
    
    show_progress 7 8 "检查核心文件"
    
    # 确保核心文件存在
    if [ ! -f "core/mcp_server.py" ]; then
        warning "核心文件不存在，创建基础结构..."
        mkdir -p core config logs
        
        # 创建基础MCP服务器
        cat > core/mcp_server.py << 'EOF'
#!/usr/bin/env python3
"""
PowerAutomation Local MCP Server
简化版本 - 用于快速启动
"""

import asyncio
import json
import logging
from datetime import datetime
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# 创建FastAPI应用
app = FastAPI(
    title="PowerAutomation Local MCP",
    description="本地MCP服务器",
    version="1.0.0"
)

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {
        "message": "PowerAutomation Local MCP Server",
        "status": "running",
        "timestamp": datetime.now().isoformat()
    }

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "service": "PowerAutomation Local MCP",
        "timestamp": datetime.now().isoformat()
    }

@app.post("/mcp/request")
async def handle_mcp_request(request: dict):
    """处理MCP请求"""
    return {
        "success": True,
        "method": request.get("method", "unknown"),
        "result": {"message": "Request processed"},
        "timestamp": datetime.now().isoformat()
    }

if __name__ == "__main__":
    print("🚀 启动PowerAutomation Local MCP服务器...")
    print("📍 服务地址: http://localhost:5000")
    print("📍 健康检查: http://localhost:5000/health")
    print("📍 API文档: http://localhost:5000/docs")
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=5000,
        log_level="info"
    )
EOF
        chmod +x core/mcp_server.py
    fi
    
    show_progress 8 8 "环境设置完成"
    printf "\n"
    success "✅ 环境设置完成"
}

# 智能配置管理
smart_configuration() {
    log "⚙️ 智能配置管理..."
    
    mkdir -p config
    
    # 创建配置文件
    cat > config/config.toml << EOF
[server]
host = "0.0.0.0"
port = 5000
debug = true
log_level = "info"

[mcp]
timeout = 30
max_connections = 100
enable_cors = true

[integration]
# EC2连接配置 - 如果有EC2实例，请更新此IP
ec2_endpoint = "http://localhost:8080"
hitl_endpoint = "http://localhost:8096"

[local]
data_dir = "./data"
log_dir = "./logs"
temp_dir = "./temp"
EOF

    # 创建启动配置
    cat > config/startup.json << EOF
{
    "service_name": "PowerAutomation Local MCP",
    "version": "1.0.0",
    "startup_time": "$(date -Iseconds)",
    "features": {
        "mcp_server": true,
        "web_interface": true,
        "api_endpoints": true,
        "health_check": true
    },
    "endpoints": {
        "main": "http://localhost:5000",
        "health": "http://localhost:5000/health",
        "docs": "http://localhost:5000/docs"
    }
}
EOF

    success "✅ 配置文件已创建"
}

# 启动服务
start_services() {
    log "🚀 启动PowerAutomation Local服务..."
    
    # 确保在正确的环境中
    source powerautomation_env/bin/activate
    
    # 创建日志目录
    mkdir -p logs
    
    # 启动MCP服务器
    info "启动MCP服务器..."
    python3 core/mcp_server.py &
    local server_pid=$!
    
    # 等待服务启动
    sleep 3
    
    # 检查服务是否启动成功
    if kill -0 $server_pid 2>/dev/null; then
        success "✅ MCP服务器启动成功 (PID: $server_pid)"
        echo $server_pid > logs/server.pid
    else
        error "❌ MCP服务器启动失败"
        exit 1
    fi
    
    # 显示服务信息
    info "📍 服务地址: http://localhost:5000"
    info "📍 健康检查: http://localhost:5000/health"
    info "📍 API文档: http://localhost:5000/docs"
}

# 快速测试验证
quick_test_verification() {
    log "🧪 快速测试验证..."
    
    # 等待服务完全启动
    sleep 2
    
    local test_passed=0
    local test_total=4
    
    # 测试1: 服务可达性
    if curl -f -s http://localhost:5000 >/dev/null 2>&1; then
        success "✅ 服务可达性测试通过"
        test_passed=$((test_passed + 1))
    else
        error "❌ 服务可达性测试失败"
    fi
    
    # 测试2: 健康检查
    if curl -f -s http://localhost:5000/health >/dev/null 2>&1; then
        success "✅ 健康检查测试通过"
        test_passed=$((test_passed + 1))
    else
        error "❌ 健康检查测试失败"
    fi
    
    # 测试3: API响应
    local api_response=$(curl -s http://localhost:5000 2>/dev/null | grep -o '"status":"running"' || echo "")
    if [ -n "$api_response" ]; then
        success "✅ API响应测试通过"
        test_passed=$((test_passed + 1))
    else
        error "❌ API响应测试失败"
    fi
    
    # 测试4: 进程检查
    if [ -f "logs/server.pid" ] && kill -0 $(cat logs/server.pid) 2>/dev/null; then
        success "✅ 进程状态测试通过"
        test_passed=$((test_passed + 1))
    else
        error "❌ 进程状态测试失败"
    fi
    
    # 显示测试结果
    info "测试结果: $test_passed/$test_total 通过"
    
    if [ $test_passed -eq $test_total ]; then
        success "🎉 所有测试通过！"
        return 0
    else
        warning "⚠️ 部分测试失败，但服务可能仍然可用"
        return 1
    fi
}

# 生成使用指南
generate_usage_guide() {
    local guide_file="USAGE_GUIDE.md"
    
    cat > "$guide_file" << EOF
# PowerAutomation Local 使用指南

## 服务信息
- **启动时间**: $(date)
- **服务地址**: http://localhost:5000
- **健康检查**: http://localhost:5000/health
- **API文档**: http://localhost:5000/docs

## 快速使用

### 1. 检查服务状态
\`\`\`bash
curl http://localhost:5000/health
\`\`\`

### 2. 查看API文档
在浏览器中访问: http://localhost:5000/docs

### 3. 发送MCP请求
\`\`\`bash
curl -X POST http://localhost:5000/mcp/request \\
  -H "Content-Type: application/json" \\
  -d '{"method": "test", "params": {}}'
\`\`\`

## 管理命令

### 停止服务
\`\`\`bash
# 使用PID文件停止
kill \$(cat logs/server.pid)

# 或者查找并停止进程
pkill -f "python3 core/mcp_server.py"
\`\`\`

### 重启服务
\`\`\`bash
# 停止服务
kill \$(cat logs/server.pid)

# 重新启动
./start_local_enhanced.sh
\`\`\`

### 查看日志
\`\`\`bash
# 查看启动日志
tail -f /tmp/start_local_*.log

# 查看服务日志
tail -f logs/*.log
\`\`\`

## 配置文件

- **主配置**: config/config.toml
- **启动配置**: config/startup.json

## 故障排除

### 端口被占用
\`\`\`bash
# 查看端口使用情况
lsof -i :5000

# 杀死占用端口的进程
kill \$(lsof -t -i:5000)
\`\`\`

### 依赖问题
\`\`\`bash
# 重新安装依赖
source powerautomation_env/bin/activate
pip install -r requirements.txt
\`\`\`

### 权限问题
\`\`\`bash
# 确保脚本有执行权限
chmod +x start_local_enhanced.sh
chmod +x core/mcp_server.py
\`\`\`

## 集成说明

### 与EC2服务集成
如果您有EC2上的AICore服务，请更新 \`config/config.toml\` 中的 \`ec2_endpoint\`。

### VSCode/Cursor扩展
本地服务启动后，VSCode/Cursor扩展可以连接到 http://localhost:5000。

**PowerAutomation Local 已成功启动！**
EOF

    info "使用指南已生成: $guide_file"
}

# 显示启动完成信息
show_completion_info() {
    echo ""
    echo "🎉 PowerAutomation Local 一键部署完成！"
    echo ""
    echo "📊 部署摘要:"
    echo "  ✅ 环境检测和安装"
    echo "  ✅ 虚拟环境创建"
    echo "  ✅ 依赖包安装"
    echo "  ✅ 配置文件生成"
    echo "  ✅ 服务启动"
    echo "  ✅ 测试验证"
    echo ""
    echo "🌐 服务访问:"
    echo "  📍 主服务: http://localhost:5000"
    echo "  📍 健康检查: http://localhost:5000/health"
    echo "  📍 API文档: http://localhost:5000/docs"
    echo ""
    echo "📁 重要文件:"
    echo "  📄 配置文件: config/config.toml"
    echo "  📄 使用指南: USAGE_GUIDE.md"
    echo "  📄 进程ID: logs/server.pid"
    echo ""
    echo "🔧 管理命令:"
    echo "  停止服务: kill \$(cat logs/server.pid)"
    echo "  查看日志: tail -f /tmp/start_local_*.log"
    echo "  重新启动: ./start_local_enhanced.sh"
    echo ""
    success "PowerAutomation Local 已准备就绪！"
}

# 主函数
main() {
    local start_time=$(date +%s)
    
    log "🚀 开始PowerAutomation Local一键部署"
    
    # 阶段1: 确保项目目录
    ensure_project_directory
    
    # 阶段2: 智能环境设置
    smart_environment_setup
    
    # 阶段3: 智能配置
    smart_configuration
    
    # 阶段4: 启动服务
    start_services
    
    # 阶段5: 测试验证
    quick_test_verification
    
    # 阶段6: 生成使用指南
    generate_usage_guide
    
    # 显示完成信息
    show_completion_info
    
    local end_time=$(date +%s)
    local total_time=$((end_time - start_time))
    
    success "🎯 一键部署完成！总耗时: ${total_time}秒"
    
    # 保持服务运行
    info "服务正在后台运行..."
    info "按 Ctrl+C 可以查看日志，但不会停止服务"
    
    # 显示实时日志（可选）
    if [ -f "logs/server.pid" ]; then
        echo ""
        echo "📊 实时服务状态 (按Ctrl+C退出监控):"
        while kill -0 $(cat logs/server.pid) 2>/dev/null; do
            local status=$(curl -s http://localhost:5000/health 2>/dev/null | grep -o '"status":"[^"]*"' | cut -d'"' -f4 || echo "unknown")
            printf "\r${GREEN}[$(date '+%H:%M:%S')]${NC} 服务状态: $status"
            sleep 5
        done
    fi
}

# 信号处理
trap 'echo ""; info "监控已停止，服务继续运行"; exit 0' INT

# 执行主函数
main "$@"

