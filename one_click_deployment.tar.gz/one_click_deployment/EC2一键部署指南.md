# EC2一键部署指南 - AICore + PowerAutomation_local

**版本**: 1.0.0  
**作者**: Manus AI  
**日期**: 2025年6月28日

---

## 概述

本指南提供了一个完整的一键部署方案，可以同时部署：
- **EC2云端**: AICore核心服务 + HITL认证服务
- **本地环境**: PowerAutomation_local组件 + VSCode扩展

### 核心特性
- 🔐 **HITL认证集成**: 自动处理AWS、GitHub等认证需求
- 🚀 **一键部署**: 单个脚本完成全部部署流程
- 🔄 **自动配置**: 自动配置服务连接和网络
- 📊 **实时监控**: 部署过程可视化和状态监控
- 🛡️ **安全保障**: 认证信息加密存储和传输

---

## 部署架构

### 整体架构图
```
┌─────────────────────────────────────────────────────────────┐
│                    EC2 云端环境                              │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │   AICore服务    │  │   HITL服务      │  │   Nginx      │ │
│  │   :8080         │  │   :8096         │  │   :80/:443   │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
│           │                     │                   │       │
│           └─────────────────────┼───────────────────┘       │
│                                 │                           │
└─────────────────────────────────┼───────────────────────────┘
                                  │ HITL认证请求
                                  ▼
┌─────────────────────────────────────────────────────────────┐
│                   本地开发环境                               │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐ │
│  │PowerAutomation  │  │   VSCode扩展    │  │  浏览器测试   │ │
│  │    _local       │  │                 │  │              │ │
│  │    :5000        │  │                 │  │              │ │
│  └─────────────────┘  └─────────────────┘  └──────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

### HITL认证流程
```
部署脚本 → 检测认证需求 → 调用HITL → SmartUI界面 → 用户输入 → 认证完成 → 继续部署
```

---

## 前置要求

### 系统要求
- **操作系统**: Linux/macOS/Windows (WSL)
- **Python**: 3.8+ 
- **Node.js**: 16+ (可选，用于VSCode扩展)
- **Git**: 最新版本
- **curl**: 用于API调用
- **jq**: JSON处理工具

### 必需工具安装
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install -y curl git jq python3 python3-pip

# macOS
brew install curl git jq python3

# 安装AWS CLI
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
```

### 认证信息准备
在开始部署前，请准备以下认证信息（部署时通过HITL界面输入）：

1. **AWS认证**
   - AWS Access Key ID
   - AWS Secret Access Key
   - AWS Region (默认: us-east-1)

2. **GitHub认证**
   - GitHub Personal Access Token
   - GitHub Username (可选)

3. **SSH密钥** (可选)
   - SSH私钥内容
   - 密钥名称

---

## 快速开始

### 1. 下载部署脚本
```bash
# 下载部署脚本包
wget https://github.com/alexchuang650730/aicore0624/releases/download/v1.0.0/ec2-deploy-package.zip
unzip ec2-deploy-package.zip
cd ec2-deploy-package

# 或者直接克隆仓库
git clone https://github.com/alexchuang650730/aicore0624.git
cd aicore0624
```

### 2. 执行一键部署
```bash
# 给脚本执行权限
chmod +x ec2_one_click_deploy.sh

# 开始部署
./ec2_one_click_deploy.sh
```

### 3. HITL认证流程
部署过程中会自动检测认证需求，如果需要认证信息：

1. **脚本暂停并显示HITL链接**
   ```
   ⚠️  需要AWS认证信息
   📱 请访问: http://18.212.49.136/hitl/abc123
   ⏳ 等待用户完成认证...
   ```

2. **在SmartUI界面完成认证**
   - 点击链接打开认证界面
   - 按提示输入认证信息
   - 点击"确认"完成认证

3. **脚本自动继续**
   ```
   ✅ 认证完成，继续部署...
   ```

---

## 部署流程详解

### 阶段1: 环境检查 (1-2分钟)
- 检查系统依赖
- 验证工具版本
- 创建日志文件

### 阶段2: 认证处理 (2-5分钟)
- 检查AWS认证状态
- 如需认证，调用HITL获取
- 检查GitHub认证状态
- 设置环境变量

### 阶段3: EC2部署 (5-10分钟)
- 创建EC2实例
- 等待实例启动
- 执行自动配置脚本
- 部署AICore和HITL服务

### 阶段4: 本地安装 (3-5分钟)
- 克隆代码仓库
- 创建Python虚拟环境
- 安装依赖包
- 配置连接参数
- 安装VSCode扩展

### 阶段5: 验证测试 (1-2分钟)
- 验证EC2服务状态
- 测试本地服务
- 验证连接性
- 生成部署报告

**总计时间**: 约12-24分钟

---

## 使用方法

### 启动本地服务
```bash
cd aicore0624/PowerAutomation_local
source powerautomation_env/bin/activate
python3 core/mcp_server.py
```

### VSCode扩展使用
1. 打开VSCode
2. 扩展会自动连接到EC2服务
3. 在侧边栏找到"PowerAutomation"面板
4. 开始使用AI助手和仓库管理功能

### 访问Web界面
- **AICore服务**: http://[EC2_IP]:8080
- **HITL界面**: http://[EC2_IP]:8096
- **健康检查**: http://[EC2_IP]:8080/health

---

## 故障排除

### 常见问题

#### 1. AWS认证失败
```bash
错误: AWS认证未配置
解决: 通过HITL界面重新输入正确的AWS认证信息
```

#### 2. EC2实例创建失败
```bash
错误: EC2实例创建失败
解决: 检查AWS权限、配额限制、网络配置
```

#### 3. 本地服务启动失败
```bash
错误: Python依赖安装失败
解决: 检查Python版本，重新运行安装脚本
```

#### 4. VSCode扩展无法连接
```bash
错误: 无法连接到EC2服务
解决: 检查EC2安全组设置，确保端口8080开放
```

### 日志查看
```bash
# 查看部署日志
tail -f /tmp/ec2_deploy_*.log

# 查看EC2服务日志
ssh ubuntu@[EC2_IP] "docker-compose logs -f"

# 查看本地服务日志
cd aicore0624/PowerAutomation_local
tail -f logs/mcp_server.log
```

### 重新部署
```bash
# 清理本地环境
rm -rf aicore0624
rm -rf powerautomation_env

# 重新运行部署脚本
./ec2_one_click_deploy.sh
```

---

## 高级配置

### 自定义EC2配置
编辑部署脚本中的配置变量：
```bash
EC2_INSTANCE_TYPE="t3.large"  # 更大的实例类型
EC2_REGION="us-west-2"        # 不同的AWS区域
```

### 自定义HITL配置
编辑 `hitl_auth_config.json` 文件：
```json
{
  "hitl_config": {
    "timeout": 600,           # 延长超时时间
    "retry_attempts": 5       # 增加重试次数
  }
}
```

### 启用HTTPS
```bash
# 在HITL认证时选择启用HTTPS
# 需要提供域名和SSL证书
```

---

## 安全注意事项

### 认证信息安全
- 所有认证信息通过HTTPS传输
- 本地存储采用加密方式
- 部署完成后自动清理临时文件

### 网络安全
- EC2安全组仅开放必要端口
- 使用Nginx反向代理
- 支持SSL/TLS加密

### 访问控制
- HITL认证支持多因素验证
- API访问需要有效Token
- 定期轮换认证密钥

---

## 维护和监控

### 自动监控
- 每5分钟健康检查
- 服务异常自动重启
- 日志自动轮转

### 手动维护
```bash
# 更新服务
ssh ubuntu@[EC2_IP] "cd /opt/powerautomation/aicore0624 && git pull && docker-compose restart"

# 查看资源使用
ssh ubuntu@[EC2_IP] "docker stats"

# 备份数据
ssh ubuntu@[EC2_IP] "tar -czf backup_$(date +%Y%m%d).tar.gz /opt/powerautomation/aicore0624/data"
```

### 扩容建议
- 监控CPU和内存使用率
- 根据负载调整实例类型
- 考虑使用负载均衡器

---

## 支持和帮助

### 技术支持
- **邮箱**: support@powerautomation.ai
- **文档**: https://docs.powerautomation.ai
- **社区**: https://community.powerautomation.ai

### 问题反馈
- **GitHub Issues**: https://github.com/alexchuang650730/aicore0624/issues
- **功能请求**: https://github.com/alexchuang650730/aicore0624/discussions

### 更新通知
- 关注GitHub仓库获取最新版本
- 订阅邮件列表获取重要更新

---

**部署成功后，您将拥有一个完整的AI驱动自动化开发环境！** 🎉

