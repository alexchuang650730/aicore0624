# PowerAutomation 一键部署包

这个压缩包包含了PowerAutomation项目的完整一键部署解决方案，支持EC2云端部署和本地环境配置。

## 📦 包含文件

### 核心部署脚本
- `ec2_fully_automated_deploy.sh` - 完全自动化EC2部署脚本（推荐）
- `ec2_one_click_deploy.sh` - EC2一键部署脚本
- `ec2_existing_instance_deploy.sh` - 现有EC2实例部署脚本
- `start_local_enhanced.sh` - 本地PowerAutomation_local增强部署脚本
- `powerautomation_local_deploy.sh` - 本地部署脚本

### 测试和验证
- `ec2_driven_test_suite.sh` - EC2驱动的测试套件
- `parallel_test_engine.sh` - 并行测试引擎
- `post_deployment_test_flow.json` - 部署后测试流程配置

### 配置文件
- `ec2_userdata.sh` - EC2用户数据脚本
- `hitl_auth_config.json` - HITL认证配置

### 文档
- `EC2一键部署指南.md` - 详细的EC2部署指南
- `EC2部署测试指南.md` - 部署测试说明
- `一键部署功能说明.md` - 功能特性说明
- `完全自动化优化报告.md` - 优化技术报告

## 🚀 快速开始

### 方法1: 完全自动化部署（推荐）
```bash
# 解压文件
tar -xzf one_click_deployment.tar.gz
cd one_click_deployment

# 赋予执行权限
chmod +x *.sh

# 执行完全自动化部署
./ec2_fully_automated_deploy.sh
```

### 方法2: 仅本地部署
```bash
# 如果只需要本地PowerAutomation_local环境
./start_local_enhanced.sh
```

### 方法3: 现有EC2实例部署
```bash
# 如果您已有EC2实例
./ec2_existing_instance_deploy.sh
```

## 📋 系统要求

### 本地环境
- Ubuntu 18.04+ 或 macOS 10.15+
- Python 3.8+
- Git
- SSH客户端

### EC2环境
- Ubuntu 22.04 LTS
- t3.medium 或更高配置
- 安全组开放端口: 22, 80, 443, 8080, 8096

## 🔧 配置说明

### 环境变量
```bash
export EC2_IP="your-ec2-ip"
export POWERAUTOMATION_EC2_IP="your-ec2-ip"
```

### SSH密钥
确保您的SSH私钥文件权限正确：
```bash
chmod 600 ~/.ssh/your-key.pem
```

## 📊 部署时间

- **完全自动化部署**: 5-8分钟
- **本地环境部署**: 2-3分钟
- **测试验证**: 1-2分钟

## 🛠️ 故障排除

1. **权限问题**: 确保所有.sh文件有执行权限
2. **网络问题**: 检查EC2安全组和网络连接
3. **SSH问题**: 验证SSH密钥和连接配置
4. **端口冲突**: 检查本地端口5000, 8080, 8096是否被占用

## 📞 支持

如遇问题，请查看相关文档或检查部署日志文件。

---
**PowerAutomation Team**  
版本: 1.0.0  
更新时间: 2025-06-28

