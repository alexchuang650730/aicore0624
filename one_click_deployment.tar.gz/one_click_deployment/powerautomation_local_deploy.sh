#!/bin/bash
# PowerAutomation Local 端侧一键部署脚本
# 功能: 检测、安装、配置、启动、测试 - 真正的一键部署
# Version: 3.0.0
# 使用方法: ./powerautomation_local_deploy.sh

set -e

# 配置变量
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_FILE="/tmp/powerautomation_deploy_$(date +%Y%m%d_%H%M%S).log"
PROJECT_DIR="aicore0624"
LOCAL_DIR="PowerAutomation_local"

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m'

# 日志函数
log() { echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1" | tee -a "$LOG_FILE"; }
error() { echo -e "${RED}[ERROR]${NC} $1" | tee -a "$LOG_FILE"; }
info() { echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$LOG_FILE"; }
success() { echo -e "${GREEN}[SUCCESS]${NC} $1" | tee -a "$LOG_FILE"; }
warning() { echo -e "${YELLOW}[WARNING]${NC} $1" | tee -a "$LOG_FILE"; }

# 进度显示
show_progress() {
    local step=$1
    local total=$2
    local desc="$3"
    local percent=$((step * 100 / total))
    printf "\r${BLUE}[%2d/%d]${NC} (%3d%%) %s" $step $total $percent "$desc"
}

# 显示欢迎信息
show_welcome() {
    clear
    echo -e "${PURPLE}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                PowerAutomation Local 一键部署                ║"
    echo "║                                                              ║"
    echo "║  🚀 端侧发动的完全自动化部署方案                              ║"
    echo "║  ⚡ 从零到运行，仅需一个命令                                  ║"
    echo "║  🔧 智能检测、自动安装、配置管理                              ║"
    echo "║  🧪 自动测试验证和服务监控                                    ║"
    echo "║                                                              ║"
    echo "║  Version: 3.0.0                                             ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    log "🎯 开始PowerAutomation Local端侧一键部署"
    echo ""
}

# 检测EC2配置
detect_ec2_config() {
    log "🔍 检测EC2配置..."
    
    # 从环境变量读取
    EC2_IP=${EC2_IP:-""}
    
    # 从配置文件读取
    if [ -f "config/ec2.conf" ]; then
        source config/ec2.conf
        info "从配置文件读取EC2_IP: $EC2_IP"
    fi
    
    # 交互式输入 (可选)
    if [ -z "$EC2_IP" ]; then
        echo ""
        echo -e "${YELLOW}🌐 EC2集成配置 (可选)${NC}"
        echo "如果您有EC2实例，可以配置SSH隧道实现云端集成"
        read -p "请输入EC2 IP地址 (留空跳过): " EC2_IP
        
        if [ -n "$EC2_IP" ]; then
            # 保存配置
            mkdir -p config
            echo "EC2_IP=$EC2_IP" > config/ec2.conf
            success "✅ EC2配置已保存"
        else
            info "跳过EC2配置，仅部署本地服务"
        fi
    fi
    
    export EC2_IP
}

# 检查并创建项目目录
ensure_project_directory() {
    log "📁 检查项目目录..."
    
    if [ ! -d "$PROJECT_DIR" ]; then
        info "项目目录不存在，开始克隆..."
        
        # 智能克隆
        if command -v git >/dev/null 2>&1; then
            show_progress 1 3 "克隆项目代码"
            git clone --depth 1 https://github.com/alexchuang650730/aicore0624.git >/dev/null 2>&1
            show_progress 2 3 "验证项目结构"
            if [ -d "$PROJECT_DIR/$LOCAL_DIR" ]; then
                show_progress 3 3 "项目克隆完成"
                printf "\n"
                success "✅ 项目克隆完成"
            else
                error "❌ 项目结构异常"
                exit 1
            fi
        else
            error "❌ Git未安装，请先安装Git"
            echo "Ubuntu/Debian: sudo apt install git"
            echo "CentOS/RHEL: sudo yum install git"
            echo "macOS: brew install git"
            exit 1
        fi
    else
        info "项目目录已存在，更新代码..."
        cd "$PROJECT_DIR" && git pull origin main >/dev/null 2>&1 || true
        cd ..
    fi
    
    cd "$PROJECT_DIR/$LOCAL_DIR"
    success "✅ 工作目录: $(pwd)"
}

# 智能环境检测和安装
smart_environment_setup() {
    log "⚙️ 智能环境检测和安装..."
    
    show_progress 1 10 "检查Python环境"
    
    # 检查Python
    if ! command -v python3 >/dev/null 2>&1; then
        error "❌ Python 3未安装"
        echo "请先安装Python 3.8+:"
        echo "Ubuntu/Debian: sudo apt install python3 python3-pip python3-venv"
        echo "CentOS/RHEL: sudo yum install python3 python3-pip"
        echo "macOS: brew install python3"
        exit 1
    fi
    
    local python_version=$(python3 --version | cut -d' ' -f2 | cut -d'.' -f1-2)
    info "Python版本: $python_version"
    
    show_progress 2 10 "检查虚拟环境"
    
    # 创建或激活虚拟环境
    if [ ! -d "powerautomation_env" ]; then
        info "创建虚拟环境..."
        python3 -m venv powerautomation_env >/dev/null 2>&1
    fi
    
    source powerautomation_env/bin/activate
    success "✅ 虚拟环境已激活"
    
    show_progress 3 10 "升级pip"
    pip install --upgrade pip >/dev/null 2>&1
    
    show_progress 4 10 "检查依赖文件"
    
    # 创建requirements.txt如果不存在
    if [ ! -f "requirements.txt" ]; then
        cat > requirements.txt << EOF
fastapi>=0.104.0
uvicorn[standard]>=0.24.0
pydantic>=2.5.0
aiohttp>=3.9.0
asyncio-mqtt>=0.13.0
playwright>=1.40.0
websockets>=12.0
python-multipart>=0.0.6
jinja2>=3.1.0
requests>=2.31.0
python-dotenv>=1.0.0
EOF
    fi
    
    show_progress 5 10 "安装Python依赖"
    pip install -r requirements.txt >/dev/null 2>&1
    
    show_progress 6 10 "安装Playwright浏览器"
    if command -v playwright >/dev/null 2>&1; then
        playwright install chromium >/dev/null 2>&1 || true
    fi
    
    show_progress 7 10 "检查核心文件"
    
    # 确保核心文件存在
    if [ ! -f "core/mcp_server.py" ]; then
        warning "核心文件不存在，创建基础结构..."
        mkdir -p core config logs data temp
        
        # 创建基础MCP服务器
        cat > core/mcp_server.py << 'EOF'
#!/usr/bin/env python3
"""
PowerAutomation Local MCP Server
端侧MCP服务器 - 支持云端集成
"""

import asyncio
import json
import logging
import os
from datetime import datetime
from typing import Dict, Any, Optional
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import uvicorn

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/mcp_server.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# 创建FastAPI应用
app = FastAPI(
    title="PowerAutomation Local MCP",
    description="端侧MCP服务器 - 支持云端集成",
    version="3.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 服务状态
service_status = {
    "start_time": datetime.now(),
    "requests_count": 0,
    "ec2_connected": False,
    "ec2_endpoint": os.getenv("EC2_ENDPOINT", "http://localhost:8080")
}

@app.middleware("http")
async def count_requests(request: Request, call_next):
    service_status["requests_count"] += 1
    response = await call_next(request)
    return response

@app.get("/", response_class=HTMLResponse)
async def root():
    """主页面"""
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>PowerAutomation Local MCP</title>
        <meta charset="utf-8">
        <style>
            body {{ font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }}
            .container {{ max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
            .header {{ text-align: center; color: #333; margin-bottom: 30px; }}
            .status {{ background: #e8f5e8; padding: 15px; border-radius: 5px; margin: 20px 0; }}
            .endpoint {{ background: #f0f8ff; padding: 10px; border-radius: 5px; margin: 10px 0; font-family: monospace; }}
            .green {{ color: #28a745; }}
            .blue {{ color: #007bff; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🚀 PowerAutomation Local MCP</h1>
                <p>端侧MCP服务器 - 版本 3.0.0</p>
            </div>
            
            <div class="status">
                <h3>📊 服务状态</h3>
                <p><strong>状态:</strong> <span class="green">运行中</span></p>
                <p><strong>启动时间:</strong> {service_status['start_time'].strftime('%Y-%m-%d %H:%M:%S')}</p>
                <p><strong>请求次数:</strong> {service_status['requests_count']}</p>
                <p><strong>EC2连接:</strong> {'✅ 已连接' if service_status['ec2_connected'] else '❌ 未连接'}</p>
            </div>
            
            <div>
                <h3>🔗 API端点</h3>
                <div class="endpoint">GET /health - 健康检查</div>
                <div class="endpoint">POST /mcp/request - MCP请求处理</div>
                <div class="endpoint">GET /docs - API文档</div>
                <div class="endpoint">GET /status - 详细状态</div>
            </div>
            
            <div>
                <h3>🌐 集成信息</h3>
                <p><strong>本地服务:</strong> <span class="blue">http://localhost:5000</span></p>
                <p><strong>EC2端点:</strong> <span class="blue">{service_status['ec2_endpoint']}</span></p>
            </div>
        </div>
    </body>
    </html>
    """
    return html_content

@app.get("/health")
async def health_check():
    """健康检查"""
    return {
        "status": "healthy",
        "service": "PowerAutomation Local MCP",
        "version": "3.0.0",
        "timestamp": datetime.now().isoformat(),
        "uptime_seconds": (datetime.now() - service_status["start_time"]).total_seconds()
    }

@app.get("/status")
async def get_status():
    """获取详细状态"""
    return {
        "service_info": {
            "name": "PowerAutomation Local MCP",
            "version": "3.0.0",
            "type": "端侧MCP服务器"
        },
        "runtime_status": {
            "start_time": service_status["start_time"].isoformat(),
            "uptime_seconds": (datetime.now() - service_status["start_time"]).total_seconds(),
            "requests_count": service_status["requests_count"],
            "memory_usage": "N/A",
            "cpu_usage": "N/A"
        },
        "integration_status": {
            "ec2_connected": service_status["ec2_connected"],
            "ec2_endpoint": service_status["ec2_endpoint"],
            "local_endpoint": "http://localhost:5000"
        },
        "features": {
            "mcp_server": True,
            "web_interface": True,
            "api_endpoints": True,
            "health_check": True,
            "ec2_integration": bool(os.getenv("EC2_IP"))
        }
    }

@app.post("/mcp/request")
async def handle_mcp_request(request: dict):
    """处理MCP请求"""
    try:
        method = request.get("method", "unknown")
        params = request.get("params", {})
        
        logger.info(f"处理MCP请求: {method}")
        
        # 基础请求处理
        result = {
            "message": f"MCP请求已处理: {method}",
            "method": method,
            "params": params,
            "processed_at": datetime.now().isoformat(),
            "server": "PowerAutomation Local MCP"
        }
        
        return {
            "success": True,
            "method": method,
            "result": result,
            "timestamp": datetime.now().isoformat(),
            "server_info": {
                "name": "PowerAutomation Local MCP",
                "version": "3.0.0",
                "type": "端侧服务器"
            }
        }
        
    except Exception as e:
        logger.error(f"MCP请求处理错误: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/test/connection")
async def test_connection():
    """测试连接"""
    return {
        "status": "connected",
        "message": "PowerAutomation Local MCP连接正常",
        "timestamp": datetime.now().isoformat()
    }

if __name__ == "__main__":
    # 确保日志目录存在
    os.makedirs("logs", exist_ok=True)
    
    print("🚀 启动PowerAutomation Local MCP服务器...")
    print("📍 本地服务: http://localhost:5000")
    print("📍 健康检查: http://localhost:5000/health")
    print("📍 API文档: http://localhost:5000/docs")
    print("📍 服务状态: http://localhost:5000/status")
    
    # 检查EC2集成
    if os.getenv("EC2_IP"):
        print(f"🌐 EC2集成: {os.getenv('EC2_IP')}")
        service_status["ec2_connected"] = True
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=5000,
        log_level="info",
        access_log=True
    )
EOF
        chmod +x core/mcp_server.py
    fi
    
    show_progress 8 10 "创建启动脚本"
    
    # 创建启动脚本
    cat > start_local.sh << 'EOF'
#!/bin/bash
# PowerAutomation Local 启动脚本

# 激活虚拟环境
source powerautomation_env/bin/activate

# 设置环境变量
export EC2_IP=${EC2_IP:-""}
export EC2_ENDPOINT="http://localhost:8080"

# 启动服务
echo "🚀 启动PowerAutomation Local MCP服务器..."
python3 core/mcp_server.py
EOF
    chmod +x start_local.sh
    
    show_progress 9 10 "创建停止脚本"
    
    # 创建停止脚本
    cat > stop_local.sh << 'EOF'
#!/bin/bash
# PowerAutomation Local 停止脚本

echo "🛑 停止PowerAutomation Local服务..."

# 查找并停止进程
if [ -f "logs/server.pid" ]; then
    PID=$(cat logs/server.pid)
    if kill -0 $PID 2>/dev/null; then
        kill $PID
        echo "✅ 服务已停止 (PID: $PID)"
    else
        echo "⚠️ 进程不存在"
    fi
    rm -f logs/server.pid
else
    # 通过进程名查找
    pkill -f "python3 core/mcp_server.py" && echo "✅ 服务已停止" || echo "⚠️ 未找到运行的服务"
fi

# 停止SSH隧道
pkill -f "ssh.*5000.*8080.*8096" && echo "✅ SSH隧道已关闭" || true
EOF
    chmod +x stop_local.sh
    
    show_progress 10 10 "环境设置完成"
    printf "\n"
    success "✅ 环境设置完成"
}

# 智能配置管理
smart_configuration() {
    log "⚙️ 智能配置管理..."
    
    mkdir -p config data logs temp
    
    # 创建主配置文件
    cat > config/config.toml << EOF
[server]
host = "0.0.0.0"
port = 5000
debug = true
log_level = "info"
workers = 1

[mcp]
timeout = 30
max_connections = 100
enable_cors = true
request_timeout = 60

[integration]
# EC2连接配置
ec2_endpoint = "http://localhost:8080"
hitl_endpoint = "http://localhost:8096"
enable_ssh_tunnel = true

[local]
data_dir = "./data"
log_dir = "./logs"
temp_dir = "./temp"
max_log_size = "10MB"
log_retention_days = 7

[features]
web_interface = true
api_documentation = true
health_check = true
status_monitoring = true
auto_restart = false
EOF

    # 创建启动配置
    cat > config/startup.json << EOF
{
    "service_name": "PowerAutomation Local MCP",
    "version": "3.0.0",
    "startup_time": "$(date -Iseconds)",
    "deployment_type": "端侧一键部署",
    "features": {
        "mcp_server": true,
        "web_interface": true,
        "api_endpoints": true,
        "health_check": true,
        "ssh_tunnel": $([ -n "$EC2_IP" ] && echo "true" || echo "false"),
        "ec2_integration": $([ -n "$EC2_IP" ] && echo "true" || echo "false")
    },
    "endpoints": {
        "main": "http://localhost:5000",
        "health": "http://localhost:5000/health",
        "docs": "http://localhost:5000/docs",
        "status": "http://localhost:5000/status"
    },
    "ec2_config": {
        "ip": "${EC2_IP:-"未配置"}",
        "aicore_tunnel": "http://localhost:8080",
        "hitl_tunnel": "http://localhost:8096"
    }
}
EOF

    # 创建环境变量文件
    cat > .env << EOF
# PowerAutomation Local 环境变量
EC2_IP=${EC2_IP:-""}
EC2_ENDPOINT=http://localhost:8080
HITL_ENDPOINT=http://localhost:8096
LOCAL_ENDPOINT=http://localhost:5000

# 服务配置
SERVER_HOST=0.0.0.0
SERVER_PORT=5000
DEBUG=true
LOG_LEVEL=info

# 功能开关
ENABLE_SSH_TUNNEL=$([ -n "$EC2_IP" ] && echo "true" || echo "false")
ENABLE_WEB_INTERFACE=true
ENABLE_API_DOCS=true
EOF

    success "✅ 配置文件已创建"
}

# 设置SSH隧道
setup_ssh_tunnel() {
    if [ -n "$EC2_IP" ]; then
        log "🔗 设置SSH隧道连接..."
        
        # 检查SSH连接
        if ssh -o ConnectTimeout=5 -o BatchMode=yes ubuntu@$EC2_IP exit 2>/dev/null; then
            success "✅ SSH连接正常"
            
            # 建立隧道
            info "建立SSH隧道..."
            ssh -f -N \
                -L 8080:localhost:8080 \
                -L 8096:localhost:8096 \
                -R 5000:localhost:5000 \
                -o ServerAliveInterval=30 \
                -o ServerAliveCountMax=3 \
                ubuntu@$EC2_IP 2>/dev/null || warning "SSH隧道建立失败"
            
            # 等待隧道建立
            sleep 2
            
            # 验证隧道
            if netstat -tlnp 2>/dev/null | grep -q ":8080.*LISTEN" || lsof -i :8080 >/dev/null 2>&1; then
                success "✅ SSH隧道已建立"
                echo "  📍 EC2 AICore: http://localhost:8080"
                echo "  📍 EC2 HITL: http://localhost:8096"
                echo "  📍 本地服务已暴露到EC2:5000"
            else
                warning "⚠️ SSH隧道状态未知"
            fi
        else
            warning "⚠️ SSH连接失败，跳过隧道设置"
            echo "  请检查:"
            echo "  1. EC2实例是否运行"
            echo "  2. SSH密钥是否正确"
            echo "  3. 安全组是否允许SSH连接"
        fi
    else
        info "未配置EC2_IP，跳过SSH隧道"
    fi
}

# 启动服务
start_services() {
    log "🚀 启动PowerAutomation Local服务..."
    
    # 确保在正确的环境中
    source powerautomation_env/bin/activate
    
    # 设置环境变量
    export EC2_IP=${EC2_IP:-""}
    export EC2_ENDPOINT="http://localhost:8080"
    
    # 创建日志目录
    mkdir -p logs
    
    # 检查端口是否被占用
    if lsof -i :5000 >/dev/null 2>&1; then
        warning "端口5000被占用，尝试停止现有服务..."
        pkill -f "python3 core/mcp_server.py" || true
        sleep 2
    fi
    
    # 启动MCP服务器
    info "启动MCP服务器..."
    nohup python3 core/mcp_server.py > logs/server.log 2>&1 &
    local server_pid=$!
    
    # 保存PID
    echo $server_pid > logs/server.pid
    
    # 等待服务启动
    sleep 3
    
    # 检查服务是否启动成功
    if kill -0 $server_pid 2>/dev/null; then
        success "✅ MCP服务器启动成功 (PID: $server_pid)"
    else
        error "❌ MCP服务器启动失败"
        if [ -f "logs/server.log" ]; then
            echo "错误日志:"
            tail -10 logs/server.log
        fi
        exit 1
    fi
}

# 快速测试验证
quick_test_verification() {
    log "🧪 快速测试验证..."
    
    # 等待服务完全启动
    sleep 3
    
    local test_passed=0
    local test_total=6
    
    echo ""
    echo "执行测试验证..."
    
    # 测试1: 服务可达性
    if curl -f -s http://localhost:5000 >/dev/null 2>&1; then
        success "✅ [1/6] 服务可达性测试通过"
        test_passed=$((test_passed + 1))
    else
        error "❌ [1/6] 服务可达性测试失败"
    fi
    
    # 测试2: 健康检查
    if curl -f -s http://localhost:5000/health >/dev/null 2>&1; then
        success "✅ [2/6] 健康检查测试通过"
        test_passed=$((test_passed + 1))
    else
        error "❌ [2/6] 健康检查测试失败"
    fi
    
    # 测试3: API响应
    local api_response=$(curl -s http://localhost:5000/health 2>/dev/null | grep -o '"status":"healthy"' || echo "")
    if [ -n "$api_response" ]; then
        success "✅ [3/6] API响应测试通过"
        test_passed=$((test_passed + 1))
    else
        error "❌ [3/6] API响应测试失败"
    fi
    
    # 测试4: 进程检查
    if [ -f "logs/server.pid" ] && kill -0 $(cat logs/server.pid) 2>/dev/null; then
        success "✅ [4/6] 进程状态测试通过"
        test_passed=$((test_passed + 1))
    else
        error "❌ [4/6] 进程状态测试失败"
    fi
    
    # 测试5: SSH隧道测试 (如果配置了EC2)
    if [ -n "$EC2_IP" ]; then
        if curl -f -s http://localhost:8080/health >/dev/null 2>&1; then
            success "✅ [5/6] EC2 AICore隧道测试通过"
            test_passed=$((test_passed + 1))
        else
            warning "⚠️ [5/6] EC2 AICore隧道测试失败"
        fi
        
        if curl -f -s http://localhost:8096 >/dev/null 2>&1; then
            success "✅ [6/6] EC2 HITL隧道测试通过"
            test_passed=$((test_passed + 1))
        else
            warning "⚠️ [6/6] EC2 HITL隧道测试失败"
        fi
    else
        info "[5/6] 跳过EC2隧道测试 (未配置EC2)"
        info "[6/6] 跳过HITL隧道测试 (未配置EC2)"
        test_total=4
    fi
    
    echo ""
    # 显示测试结果
    if [ $test_passed -eq $test_total ]; then
        success "🎉 所有测试通过！($test_passed/$test_total)"
        return 0
    elif [ $test_passed -gt $((test_total / 2)) ]; then
        warning "⚠️ 部分测试通过，服务基本可用 ($test_passed/$test_total)"
        return 0
    else
        error "❌ 多数测试失败，请检查配置 ($test_passed/$test_total)"
        return 1
    fi
}

# 生成使用指南
generate_usage_guide() {
    local guide_file="USAGE_GUIDE.md"
    
    cat > "$guide_file" << EOF
# PowerAutomation Local 使用指南

## 🎯 部署信息
- **部署时间**: $(date)
- **部署类型**: 端侧一键部署
- **版本**: 3.0.0
- **EC2集成**: $([ -n "$EC2_IP" ] && echo "已启用 ($EC2_IP)" || echo "未配置")

## 🌐 服务访问

### 本地服务
- **主服务**: http://localhost:5000
- **健康检查**: http://localhost:5000/health
- **API文档**: http://localhost:5000/docs
- **服务状态**: http://localhost:5000/status

$([ -n "$EC2_IP" ] && cat << 'EOFEC2'
### EC2服务 (通过SSH隧道)
- **AICore服务**: http://localhost:8080
- **HITL服务**: http://localhost:8096
- **EC2实例**: $EC2_IP
EOFEC2
)

## 🔧 管理命令

### 服务控制
\`\`\`bash
# 启动服务
./start_local.sh

# 停止服务
./stop_local.sh

# 重启服务
./stop_local.sh && ./start_local.sh
\`\`\`

### 状态检查
\`\`\`bash
# 检查服务状态
curl http://localhost:5000/health

# 查看详细状态
curl http://localhost:5000/status

# 检查进程
ps aux | grep "python3 core/mcp_server.py"

# 查看端口
netstat -tlnp | grep :5000
lsof -i :5000
\`\`\`

### 日志查看
\`\`\`bash
# 查看服务日志
tail -f logs/server.log

# 查看部署日志
tail -f /tmp/powerautomation_deploy_*.log

# 查看所有日志文件
ls -la logs/
\`\`\`

$([ -n "$EC2_IP" ] && cat << 'EOFEC2'
### SSH隧道管理
\`\`\`bash
# 查看隧道状态
ps aux | grep "ssh.*8080"

# 重建隧道
pkill -f "ssh.*5000.*8080.*8096"
ssh -f -N -L 8080:localhost:8080 -L 8096:localhost:8096 -R 5000:localhost:5000 ubuntu@$EC2_IP

# 测试隧道连接
curl http://localhost:8080/health  # EC2 AICore
curl http://localhost:8096         # EC2 HITL
\`\`\`
EOFEC2
)

## 🧪 测试验证

### 基础功能测试
\`\`\`bash
# 测试本地服务
curl http://localhost:5000
curl http://localhost:5000/health

# 测试MCP请求
curl -X POST http://localhost:5000/mcp/request \\
  -H "Content-Type: application/json" \\
  -d '{"method": "test", "params": {}}'

# 测试连接
curl -X POST http://localhost:5000/test/connection
\`\`\`

$([ -n "$EC2_IP" ] && cat << 'EOFEC2'
### EC2集成测试
\`\`\`bash
# 测试EC2服务访问
curl http://localhost:8080/health
curl http://localhost:8096

# 在EC2上测试本地服务访问
ssh ubuntu@$EC2_IP "curl http://localhost:5000/health"
\`\`\`
EOFEC2
)

## 📁 文件结构

\`\`\`
PowerAutomation_local/
├── core/
│   └── mcp_server.py          # MCP服务器主文件
├── config/
│   ├── config.toml            # 主配置文件
│   ├── startup.json           # 启动配置
│   └── ec2.conf              # EC2配置 (如果有)
├── logs/
│   ├── server.log            # 服务日志
│   ├── server.pid            # 进程ID
│   └── mcp_server.log        # MCP日志
├── data/                     # 数据目录
├── temp/                     # 临时文件
├── powerautomation_env/      # Python虚拟环境
├── start_local.sh            # 启动脚本
├── stop_local.sh             # 停止脚本
├── requirements.txt          # Python依赖
├── .env                      # 环境变量
└── USAGE_GUIDE.md           # 本指南
\`\`\`

## 🔧 配置说明

### 主配置文件 (config/config.toml)
- 服务器设置: 端口、主机、调试模式
- MCP配置: 超时、连接数、CORS
- 集成配置: EC2端点、HITL端点
- 本地配置: 数据目录、日志设置

### 环境变量 (.env)
- EC2_IP: EC2实例IP地址
- EC2_ENDPOINT: EC2服务端点
- SERVER_PORT: 本地服务端口
- DEBUG: 调试模式开关

## 🚨 故障排除

### 常见问题

#### 1. 端口被占用
\`\`\`bash
# 查找占用进程
lsof -i :5000

# 停止占用进程
kill -9 \$(lsof -t -i:5000)
\`\`\`

#### 2. 虚拟环境问题
\`\`\`bash
# 重新创建虚拟环境
rm -rf powerautomation_env
python3 -m venv powerautomation_env
source powerautomation_env/bin/activate
pip install -r requirements.txt
\`\`\`

#### 3. SSH隧道连接失败
\`\`\`bash
# 检查SSH连接
ssh -v ubuntu@$EC2_IP

# 检查EC2安全组
# 确保22端口对您的IP开放

# 检查SSH密钥
chmod 600 ~/.ssh/your-key.pem
\`\`\`

#### 4. 服务启动失败
\`\`\`bash
# 查看详细错误
cat logs/server.log

# 手动启动调试
source powerautomation_env/bin/activate
python3 core/mcp_server.py
\`\`\`

### 获取帮助
- 查看API文档: http://localhost:5000/docs
- 查看服务状态: http://localhost:5000/status
- 查看日志文件: logs/server.log

---

**PowerAutomation Local 已成功部署并运行！**

如有问题，请检查日志文件或联系技术支持。
EOF

    info "使用指南已生成: $guide_file"
}

# 显示启动完成信息
show_completion_info() {
    clear
    echo -e "${GREEN}"
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                🎉 部署完成！                                  ║"
    echo "║            PowerAutomation Local 已成功启动                  ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    
    echo -e "${BLUE}📊 部署摘要:${NC}"
    echo "  ✅ 环境检测和安装"
    echo "  ✅ 虚拟环境创建"
    echo "  ✅ 依赖包安装"
    echo "  ✅ 配置文件生成"
    echo "  ✅ 服务启动"
    echo "  ✅ 测试验证"
    if [ -n "$EC2_IP" ]; then
        echo "  ✅ SSH隧道建立"
    fi
    echo ""
    
    echo -e "${BLUE}🌐 服务访问:${NC}"
    echo "  📍 主服务: http://localhost:5000"
    echo "  📍 健康检查: http://localhost:5000/health"
    echo "  📍 API文档: http://localhost:5000/docs"
    echo "  📍 服务状态: http://localhost:5000/status"
    
    if [ -n "$EC2_IP" ]; then
        echo ""
        echo -e "${BLUE}🌐 EC2服务 (通过SSH隧道):${NC}"
        echo "  📍 AICore服务: http://localhost:8080"
        echo "  📍 HITL服务: http://localhost:8096"
        echo "  📍 EC2实例: $EC2_IP"
    fi
    
    echo ""
    echo -e "${BLUE}📁 重要文件:${NC}"
    echo "  📄 配置文件: config/config.toml"
    echo "  📄 使用指南: USAGE_GUIDE.md"
    echo "  📄 进程ID: logs/server.pid"
    echo "  📄 服务日志: logs/server.log"
    echo ""
    
    echo -e "${BLUE}🔧 管理命令:${NC}"
    echo "  启动服务: ./start_local.sh"
    echo "  停止服务: ./stop_local.sh"
    echo "  查看日志: tail -f logs/server.log"
    echo "  服务状态: curl http://localhost:5000/health"
    echo ""
    
    success "🎯 PowerAutomation Local 已准备就绪！"
    echo ""
    
    # 显示实时状态
    echo -e "${YELLOW}📊 实时服务监控 (按Ctrl+C退出):${NC}"
    echo ""
}

# 实时监控
real_time_monitoring() {
    local count=0
    while true; do
        if [ -f "logs/server.pid" ] && kill -0 $(cat logs/server.pid) 2>/dev/null; then
            local status=$(curl -s http://localhost:5000/health 2>/dev/null | grep -o '"status":"[^"]*"' | cut -d'"' -f4 || echo "unknown")
            local uptime=$(curl -s http://localhost:5000/health 2>/dev/null | grep -o '"uptime_seconds":[0-9.]*' | cut -d':' -f2 || echo "0")
            local uptime_formatted=$(printf "%.0f" $uptime 2>/dev/null || echo "0")
            
            printf "\r${GREEN}[$(date '+%H:%M:%S')]${NC} 状态: $status | 运行时间: ${uptime_formatted}秒 | 检查次数: $((++count))"
        else
            printf "\r${RED}[$(date '+%H:%M:%S')]${NC} 状态: 服务已停止"
            break
        fi
        sleep 5
    done
    echo ""
}

# 信号处理
cleanup() {
    echo ""
    info "监控已停止，服务继续在后台运行"
    echo ""
    echo "管理服务:"
    echo "  查看状态: curl http://localhost:5000/health"
    echo "  停止服务: ./stop_local.sh"
    echo "  查看日志: tail -f logs/server.log"
    exit 0
}

# 主函数
main() {
    local start_time=$(date +%s)
    
    # 显示欢迎信息
    show_welcome
    
    # 阶段1: 检测EC2配置
    detect_ec2_config
    
    # 阶段2: 确保项目目录
    ensure_project_directory
    
    # 阶段3: 智能环境设置
    smart_environment_setup
    
    # 阶段4: 智能配置
    smart_configuration
    
    # 阶段5: 设置SSH隧道
    setup_ssh_tunnel
    
    # 阶段6: 启动服务
    start_services
    
    # 阶段7: 测试验证
    if quick_test_verification; then
        # 阶段8: 生成使用指南
        generate_usage_guide
        
        # 显示完成信息
        show_completion_info
        
        local end_time=$(date +%s)
        local total_time=$((end_time - start_time))
        
        success "🎯 一键部署完成！总耗时: ${total_time}秒"
        echo ""
        
        # 设置信号处理
        trap cleanup INT
        
        # 开始实时监控
        real_time_monitoring
    else
        error "部署验证失败，请检查日志"
        exit 1
    fi
}

# 检查是否以root用户运行
if [ "$EUID" -eq 0 ]; then
    warning "⚠️ 不建议以root用户运行此脚本"
    read -p "是否继续? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# 执行主函数
main "$@"

