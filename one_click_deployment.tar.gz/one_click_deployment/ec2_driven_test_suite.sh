#!/bin/bash
# EC2驱动的测试套件 - VSIX扩展和Local Server专项测试
# 由EC2脚本远程驱动本地测试执行
# Version: 1.0.0

set -e

# 配置变量
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_LOG="/tmp/ec2_test_$(date +%Y%m%d_%H%M%S).log"
EC2_INSTANCE_IP=""
EC2_SSH_KEY=""

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 日志函数
log() { echo -e "${GREEN}[$(date '+%H:%M:%S')]${NC} $1" | tee -a "$TEST_LOG"; }
error() { echo -e "${RED}[ERROR]${NC} $1" | tee -a "$TEST_LOG"; }
info() { echo -e "${BLUE}[INFO]${NC} $1" | tee -a "$TEST_LOG"; }
success() { echo -e "${GREEN}[SUCCESS]${NC} $1" | tee -a "$TEST_LOG"; }

# 测试结果统计
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0

# 测试结果记录
test_result() {
    local test_name="$1"
    local result="$2"
    local message="$3"
    
    TOTAL_TESTS=$((TOTAL_TESTS + 1))
    
    if [ "$result" = "PASS" ]; then
        PASSED_TESTS=$((PASSED_TESTS + 1))
        success "✅ $test_name: $message"
    else
        FAILED_TESTS=$((FAILED_TESTS + 1))
        error "❌ $test_name: $message"
    fi
}

# 获取EC2连接信息
get_connection_info() {
    if [ -z "$EC2_INSTANCE_IP" ]; then
        echo -n "请输入EC2实例IP: "
        read EC2_INSTANCE_IP
    fi
    
    if [ -z "$EC2_SSH_KEY" ]; then
        echo -n "请输入SSH密钥路径 (默认: ~/.ssh/id_rsa): "
        read EC2_SSH_KEY
        EC2_SSH_KEY=${EC2_SSH_KEY:-~/.ssh/id_rsa}
    fi
    
    # 测试连接
    if ssh -o ConnectTimeout=5 -o StrictHostKeyChecking=no -i "$EC2_SSH_KEY" ubuntu@"$EC2_INSTANCE_IP" "echo 'Connected'" >/dev/null 2>&1; then
        log "EC2连接测试成功: $EC2_INSTANCE_IP"
    else
        error "无法连接到EC2实例: $EC2_INSTANCE_IP"
        exit 1
    fi
}

# EC2端服务状态测试
test_ec2_services() {
    log "🔍 测试EC2端服务状态..."
    
    # 创建EC2端测试脚本
    cat > /tmp/ec2_service_test.sh << 'EOF'
#!/bin/bash
set -e

echo "=== EC2服务状态测试 ==="

# 测试AICore服务
echo "测试AICore服务..."
if curl -f -s http://localhost:8080/health >/dev/null 2>&1; then
    echo "PASS:AICore服务运行正常"
else
    echo "FAIL:AICore服务异常"
    exit 1
fi

# 测试HITL服务
echo "测试HITL服务..."
if curl -f -s http://localhost:8096/health >/dev/null 2>&1; then
    echo "PASS:HITL服务运行正常"
else
    echo "WARN:HITL服务可能未启动"
fi

# 测试Docker容器状态
echo "测试Docker容器状态..."
if docker-compose ps | grep -q "Up"; then
    echo "PASS:Docker容器运行正常"
else
    echo "FAIL:Docker容器状态异常"
    exit 1
fi

# 测试API响应
echo "测试API响应..."
API_RESPONSE=$(curl -s -X GET http://localhost:8080/api/status || echo "ERROR")
if [ "$API_RESPONSE" != "ERROR" ]; then
    echo "PASS:API响应正常"
else
    echo "FAIL:API响应异常"
fi

echo "=== EC2服务测试完成 ==="
EOF

    # 上传并执行测试
    scp -i "$EC2_SSH_KEY" /tmp/ec2_service_test.sh ubuntu@"$EC2_INSTANCE_IP":/tmp/
    local test_output=$(ssh -i "$EC2_SSH_KEY" ubuntu@"$EC2_INSTANCE_IP" "chmod +x /tmp/ec2_service_test.sh && /tmp/ec2_service_test.sh" 2>&1)
    
    # 解析测试结果
    echo "$test_output" | while IFS= read -r line; do
        if [[ $line == PASS:* ]]; then
            test_result "EC2服务" "PASS" "${line#PASS:}"
        elif [[ $line == FAIL:* ]]; then
            test_result "EC2服务" "FAIL" "${line#FAIL:}"
        elif [[ $line == WARN:* ]]; then
            info "⚠️ ${line#WARN:}"
        fi
    done
}

# 本地PowerAutomation_local服务测试
test_local_server() {
    log "🔍 测试本地PowerAutomation_local服务..."
    
    # 检查本地环境
    if [ ! -d "aicore0624/PowerAutomation_local" ]; then
        test_result "本地环境" "FAIL" "PowerAutomation_local目录不存在"
        return 1
    fi
    
    cd aicore0624/PowerAutomation_local
    
    # 测试虚拟环境
    if [ -d "powerautomation_env" ]; then
        test_result "虚拟环境" "PASS" "Python虚拟环境存在"
    else
        test_result "虚拟环境" "FAIL" "Python虚拟环境不存在"
        return 1
    fi
    
    # 激活虚拟环境
    source powerautomation_env/bin/activate
    
    # 测试依赖包
    if python3 -c "import mcp, asyncio, aiohttp" 2>/dev/null; then
        test_result "依赖包" "PASS" "Python依赖包安装正确"
    else
        test_result "依赖包" "FAIL" "Python依赖包缺失"
    fi
    
    # 测试MCP服务器启动
    info "启动本地MCP服务器进行测试..."
    
    # 创建测试启动脚本
    cat > test_mcp_start.py << 'EOF'
import asyncio
import sys
import signal
import time
from core.mcp_server import MCPServer

class TestMCPServer:
    def __init__(self):
        self.server = None
        self.running = False
    
    async def start_test_server(self):
        try:
            self.server = MCPServer()
            self.running = True
            print("PASS:MCP服务器启动成功")
            
            # 运行5秒后停止
            await asyncio.sleep(5)
            print("PASS:MCP服务器运行稳定")
            
        except Exception as e:
            print(f"FAIL:MCP服务器启动失败: {e}")
            sys.exit(1)
        finally:
            self.running = False

if __name__ == "__main__":
    test_server = TestMCPServer()
    asyncio.run(test_server.start_test_server())
EOF

    # 运行MCP服务器测试
    local mcp_output=$(timeout 15 python3 test_mcp_start.py 2>&1 || echo "TIMEOUT:MCP服务器测试超时")
    
    # 解析MCP测试结果
    echo "$mcp_output" | while IFS= read -r line; do
        if [[ $line == PASS:* ]]; then
            test_result "本地MCP" "PASS" "${line#PASS:}"
        elif [[ $line == FAIL:* ]]; then
            test_result "本地MCP" "FAIL" "${line#FAIL:}"
        elif [[ $line == TIMEOUT:* ]]; then
            test_result "本地MCP" "FAIL" "${line#TIMEOUT:}"
        fi
    done
    
    # 测试配置文件
    if grep -q "$EC2_INSTANCE_IP" config/config.toml 2>/dev/null; then
        test_result "配置文件" "PASS" "EC2连接配置正确"
    else
        test_result "配置文件" "FAIL" "EC2连接配置缺失"
    fi
    
    # 清理测试文件
    rm -f test_mcp_start.py
}

# VSIX扩展测试
test_vsix_extension() {
    log "🔍 测试VSIX扩展..."
    
    cd aicore0624/PowerAutomation_local/vscode-extension
    
    # 测试VSIX文件存在
    if [ -f "powerautomation-local-mcp-3.1.2.vsix" ]; then
        test_result "VSIX文件" "PASS" "扩展文件存在"
        
        # 获取文件大小
        local file_size=$(ls -lh powerautomation-local-mcp-3.1.2.vsix | awk '{print $5}')
        info "VSIX文件大小: $file_size"
    else
        test_result "VSIX文件" "FAIL" "扩展文件不存在"
        return 1
    fi
    
    # 测试package.json
    if [ -f "package.json" ]; then
        local ext_name=$(python3 -c "import json; print(json.load(open('package.json')).get('name', 'unknown'))" 2>/dev/null || echo "unknown")
        local ext_version=$(python3 -c "import json; print(json.load(open('package.json')).get('version', 'unknown'))" 2>/dev/null || echo "unknown")
        
        if [ "$ext_name" != "unknown" ] && [ "$ext_version" != "unknown" ]; then
            test_result "扩展信息" "PASS" "名称: $ext_name, 版本: $ext_version"
        else
            test_result "扩展信息" "FAIL" "无法读取扩展信息"
        fi
    else
        test_result "扩展配置" "FAIL" "package.json不存在"
    fi
    
    # 测试编辑器安装状态
    local editor_found=false
    
    # 检查Cursor
    if command -v cursor &> /dev/null; then
        editor_found=true
        info "检测到Cursor编辑器"
        
        # 检查扩展是否已安装
        if cursor --list-extensions 2>/dev/null | grep -q "powerautomation" || 
           cursor --list-extensions 2>/dev/null | grep -q "local-mcp"; then
            test_result "Cursor扩展" "PASS" "扩展已安装到Cursor"
        else
            # 尝试安装扩展
            if cursor --install-extension powerautomation-local-mcp-3.1.2.vsix >/dev/null 2>&1; then
                test_result "Cursor扩展" "PASS" "扩展安装成功"
            else
                test_result "Cursor扩展" "FAIL" "扩展安装失败"
            fi
        fi
    fi
    
    # 检查VSCode
    if command -v code &> /dev/null; then
        editor_found=true
        info "检测到VSCode编辑器"
        
        # 检查扩展是否已安装
        if code --list-extensions 2>/dev/null | grep -q "powerautomation" || 
           code --list-extensions 2>/dev/null | grep -q "local-mcp"; then
            test_result "VSCode扩展" "PASS" "扩展已安装到VSCode"
        else
            # 尝试安装扩展
            if code --install-extension powerautomation-local-mcp-3.1.2.vsix >/dev/null 2>&1; then
                test_result "VSCode扩展" "PASS" "扩展安装成功"
            else
                test_result "VSCode扩展" "FAIL" "扩展安装失败"
            fi
        fi
    fi
    
    if [ "$editor_found" = false ]; then
        test_result "编辑器" "FAIL" "未检测到VSCode或Cursor"
    fi
}

# 连接性测试
test_connectivity() {
    log "🔍 测试连接性..."
    
    # 测试本地到EC2连接
    if curl -f -s "http://$EC2_INSTANCE_IP:8080/health" >/dev/null 2>&1; then
        test_result "本地到EC2" "PASS" "连接正常"
    else
        test_result "本地到EC2" "FAIL" "连接失败"
    fi
    
    # 测试EC2到本地连接（如果本地服务运行）
    if curl -f -s "http://localhost:5000/health" >/dev/null 2>&1; then
        test_result "本地服务" "PASS" "本地服务可访问"
    else
        info "本地服务未运行，跳过测试"
    fi
    
    # 测试网络延迟
    local ping_result=$(ping -c 3 "$EC2_INSTANCE_IP" 2>/dev/null | grep "avg" | awk -F'/' '{print $5}' || echo "N/A")
    if [ "$ping_result" != "N/A" ]; then
        test_result "网络延迟" "PASS" "平均延迟: ${ping_result}ms"
    else
        test_result "网络延迟" "FAIL" "无法测量延迟"
    fi
}

# EC2驱动的综合测试
run_ec2_driven_comprehensive_test() {
    log "🚀 开始EC2驱动的综合测试..."
    
    # 创建EC2端综合测试脚本
    cat > /tmp/ec2_comprehensive_test.sh << 'EOF'
#!/bin/bash
set -e

echo "=== EC2驱动综合测试 ==="

# 测试服务间通信
echo "测试服务间通信..."
cd aicore0624

# 测试MCP组件加载
if python3 -c "
import sys
sys.path.append('PowerAutomation')
from components.mcp.core.main import MCPCore
print('PASS:MCP组件加载成功')
" 2>/dev/null; then
    echo "PASS:MCP组件加载成功"
else
    echo "FAIL:MCP组件加载失败"
fi

# 测试HITL组件
if python3 -c "
import sys
sys.path.append('PowerAutomation')
from components.human_loop_mcp.main import HumanLoopMCPClient
print('PASS:HITL组件加载成功')
" 2>/dev/null; then
    echo "PASS:HITL组件加载成功"
else
    echo "FAIL:HITL组件加载失败"
fi

# 测试API端点
echo "测试API端点..."
for endpoint in "/health" "/api/status" "/api/mcp/tools"; do
    if curl -f -s "http://localhost:8080$endpoint" >/dev/null 2>&1; then
        echo "PASS:API端点 $endpoint 正常"
    else
        echo "FAIL:API端点 $endpoint 异常"
    fi
done

echo "=== EC2综合测试完成 ==="
EOF

    # 执行EC2端测试
    scp -i "$EC2_SSH_KEY" /tmp/ec2_comprehensive_test.sh ubuntu@"$EC2_INSTANCE_IP":/tmp/
    local ec2_output=$(ssh -i "$EC2_SSH_KEY" ubuntu@"$EC2_INSTANCE_IP" "chmod +x /tmp/ec2_comprehensive_test.sh && /tmp/ec2_comprehensive_test.sh" 2>&1)
    
    # 解析EC2测试结果
    echo "$ec2_output" | while IFS= read -r line; do
        if [[ $line == PASS:* ]]; then
            test_result "EC2综合" "PASS" "${line#PASS:}"
        elif [[ $line == FAIL:* ]]; then
            test_result "EC2综合" "FAIL" "${line#FAIL:}"
        fi
    done
}

# 生成测试报告
generate_test_report() {
    local report_file="ec2_driven_test_report_$(date +%Y%m%d_%H%M%S).md"
    
    cat > "$report_file" << EOF
# EC2驱动测试报告

**测试时间**: $(date)
**EC2实例**: $EC2_INSTANCE_IP
**测试版本**: 1.0.0

## 测试统计

- **总测试数**: $TOTAL_TESTS
- **通过测试**: $PASSED_TESTS
- **失败测试**: $FAILED_TESTS
- **成功率**: $(( PASSED_TESTS * 100 / TOTAL_TESTS ))%

## 测试详情

### 1. EC2服务测试
- AICore服务状态
- HITL服务状态  
- Docker容器状态
- API响应测试

### 2. 本地服务测试
- PowerAutomation_local环境
- Python虚拟环境
- MCP服务器启动
- 配置文件验证

### 3. VSIX扩展测试
- 扩展文件完整性
- 编辑器安装状态
- 版本信息验证

### 4. 连接性测试
- 本地到EC2连接
- 网络延迟测试
- 服务可达性验证

### 5. 综合功能测试
- 组件加载测试
- API端点测试
- 服务间通信测试

## 测试结论

$(if [ $FAILED_TESTS -eq 0 ]; then
    echo "✅ 所有测试通过，系统运行正常"
else
    echo "⚠️ 发现 $FAILED_TESTS 个问题，需要检查和修复"
fi)

## 日志文件
- 测试日志: $TEST_LOG
EOF

    log "测试报告已生成: $report_file"
}

# 主函数
main() {
    log "🧪 开始EC2驱动的测试套件"
    
    # 获取连接信息
    get_connection_info
    
    # 执行各项测试
    test_ec2_services
    test_local_server
    test_vsix_extension
    test_connectivity
    run_ec2_driven_comprehensive_test
    
    # 生成测试报告
    generate_test_report
    
    # 显示测试总结
    log "🎯 测试完成总结:"
    log "总测试数: $TOTAL_TESTS"
    log "通过: $PASSED_TESTS"
    log "失败: $FAILED_TESTS"
    
    if [ $FAILED_TESTS -eq 0 ]; then
        success "🎉 所有测试通过！"
        exit 0
    else
        error "⚠️ 发现 $FAILED_TESTS 个问题"
        exit 1
    fi
}

# 执行主函数
main "$@"

